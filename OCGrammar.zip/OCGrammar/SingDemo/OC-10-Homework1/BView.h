//
//  BView.h
//  OC-10-Homework1
//
//  Created by Ibokan on 14-11-28.
//  Copyright (c) 2014年 fghf. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BView : NSObject

//这里只要求能够得到这个城市就可以
- (void)printCity;

@end




