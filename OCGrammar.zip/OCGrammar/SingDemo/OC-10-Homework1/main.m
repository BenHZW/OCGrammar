//
//  main.m
//  OC-10-Homework1
//
//  Created by Ibokan on 14-11-28.
//  Copyright (c) 2014年 fghf. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AView.h"
#import "BView.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        //创建一个A，传入城市
        AView *a = [AView new];
        [a setCity:@"广州"];
        
        //创建一个B，打印城市
        BView *b = [BView new];
        [b printCity];
        
    }
    return 0;
}

