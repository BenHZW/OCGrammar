//
//  CitySingleton.h
//  OC-10-Homework1
//
//  Created by Ibokan on 14-11-28.
//  Copyright (c) 2014年 fghf. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CitySingleton : NSObject

//这是ARC环境下的单例
@property(nonatomic, copy)NSString *cityName;

//instancetype表示当前这个类
+ (instancetype)sharedCity;

@end





