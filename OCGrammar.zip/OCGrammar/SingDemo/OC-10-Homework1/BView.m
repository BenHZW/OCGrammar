//
//  BView.m
//  OC-10-Homework1
//
//  Created by Ibokan on 14-11-28.
//  Copyright (c) 2014年 fghf. All rights reserved.
//

#import "BView.h"
#import "CitySingleton.h"
@implementation BView

- (void)printCity
{
    //获得单例对象，并提取城市名称
    CitySingleton *citysingleton = [CitySingleton sharedCity];
    
    NSLog(@"city: %@", citysingleton.cityName);
}

@end




