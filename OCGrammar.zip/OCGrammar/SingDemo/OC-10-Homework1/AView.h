//
//  AView.h
//  OC-10-Homework1
//
//  Created by Ibokan on 14-11-28.
//  Copyright (c) 2014年 fghf. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AView : NSObject

- (void)setCity:(NSString*)city;

@end






