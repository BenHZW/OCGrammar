//
//  CitySingleton.m
//  OC-10-Homework1
//
//  Created by Ibokan on 14-11-28.
//  Copyright (c) 2014年 fghf. All rights reserved.
//

#import "CitySingleton.h"

static CitySingleton *cs = nil;

@implementation CitySingleton

+ (instancetype)sharedCity
{
    @synchronized(self)
    {
        if (cs == nil)
        {
            cs = [CitySingleton new];
        }
    }
    return cs;
}

//在ARC下，不需要重写retain、release等等方法

@end




