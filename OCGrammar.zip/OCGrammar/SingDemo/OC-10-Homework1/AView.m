//
//  AView.m
//  OC-10-Homework1
//
//  Created by Ibokan on 14-11-28.
//  Copyright (c) 2014年 fghf. All rights reserved.
//

#import "AView.h"
#import "CitySingleton.h"
@implementation AView

- (void)setCity:(NSString *)city
{
    //取出单例对象，然后赋值
    CitySingleton *citySingleton = [CitySingleton sharedCity];
    
    citySingleton.cityName = city;
    
}

@end



