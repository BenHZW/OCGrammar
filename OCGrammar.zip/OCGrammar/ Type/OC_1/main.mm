//
//  main.m
//  OC_1
//
//  Created by Ibokan_Teacher on 15/8/17.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>

#ifdef DEBUG
# define DLog(fmt, ...) NSLog((@"[函数名:%s]" "[行号:%d] \n" fmt), __FUNCTION__, __LINE__, ##__VA_ARGS__);
#else
# define DLog(...);
#endif

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSLog(@"Hello, World!");
        
        
        //OC完全兼容C语言
        
        //1.基本数据类型
        int i1 = 0;
        float f1 = 1.2;
        double d1 = 2.71;
        char c1 = 'r';
        
        //2.OC使用的基本数据类型
        NSInteger nsi = 6;
        NSUInteger unsi = 888;
        CGFloat cgf1 = 4.1;
        
        //布尔型
        BOOL b1 = YES;
        b1 = NO;
        
        
        //3.NSLog的用法
        NSLog(@"%ld, %f, %d", nsi, cgf1, b1);
        
        
       
        /*Dlog(@"%ld, %f, %d", nsi, cgf1, b1);*/
        //4.将.m文件改成.mm即可兼容C++
        
    }
    return 0;
}





