//
//  Car.m
//  OC_4
//
//  Created by Ibokan_Teacher on 15/8/20.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import "Car.h"

@implementation Car

- (void)setTyre:(Tyre *)tyre atIndex:(NSUInteger)index
{
    //判断下标合法性
    if (index <= 3)
    {
        _tyres[index] = tyre;
    }
}

- (Tyre *)tyreAtIndex:(NSUInteger)index
{
    //检查下标合法性
    if (index <= 3)
    {
        return _tyres[index];
    }
    else
    {
        //下标不合法则返回空指针
        return nil;
    }
}

- (NSString *)description
{
    return [NSString stringWithFormat:@"Car: %@\nEngine:%@\nTyres: %@,%@,%@,%@", self.brand, self.engine, _tyres[0], _tyres[1], _tyres[2], _tyres[3]];
}

@end








