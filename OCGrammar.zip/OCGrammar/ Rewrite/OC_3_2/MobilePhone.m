//
//  MobilePhone.m
//  OC_3_2
//
//  Created by Ibokan_Teacher on 15/8/19.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import "MobilePhone.h"

@implementation MobilePhone

- (void)sendSMS:(NSString *)sms toNumber:(NSString *)number
{
    //先拨号连接
    [self dial:number];
    
    NSLog(@"Mobilephone send sms: %@", sms);
}


//为了在拨号时打印一些额外信息，重写拨号方法
- (void)dial:(NSString *)number
{
    //功能其实与父类完全一致
    [super dial:number];
    NSLog(@"Mobilephone dial");
}



@end








