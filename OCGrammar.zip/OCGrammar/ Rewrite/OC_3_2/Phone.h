//
//  Phone.h
//  OC_3_2
//
//  Created by Ibokan_Teacher on 15/8/19.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Phone : NSObject

//拨号功能
- (void)dial:(NSString *)number;

@end









