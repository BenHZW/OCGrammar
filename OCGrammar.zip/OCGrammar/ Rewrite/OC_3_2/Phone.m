//
//  Phone.m
//  OC_3_2
//
//  Created by Ibokan_Teacher on 15/8/19.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import "Phone.h"

@implementation Phone

- (void)dial:(NSString *)number
{
    NSLog(@"Phone");
    NSLog(@"connect to %@", number);
}

@end







