//
//  main.m
//  OC_3_2
//
//  Created by Ibokan_Teacher on 15/8/19.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Phone.h"
#import "Person.h"
#import "MobilePhone.h"
#import "FaxMachine.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        //1.万能指针接受任意对象
        
        MobilePhone *mp1 = [MobilePhone new];
        FaxMachine *fm1 = [FaxMachine new];
        
        //id是能用于接受任何对象的万能指针
        id obj1 = mp1;
        id obj2 = fm1;
        
        
        //万能指针可以调用任何类的实例方法
        //但如果调用了一个对象所不具有的方法，则会引发运行时错误
        //[obj1 dialNumber:@"999" usingPhone:obj2];
        
        
        //2.父类指针接收子类对象
        Phone *p1 = mp1;
        Phone *p2 = fm1;
        
        
        //通过父类指针只能调用父类与子类共有方法
        [p1 dial:@"999"];
        
        
        
        //3.多态在实际使用中体现出便利
        NSLog(@"--------------");
        
        Person *person = [Person new];
        person.name = @"Ged";
        
        //例如在调用方法时，可以将子类对象当做父类参数传入
        [person dialNumber:@"1234567" usingPhone:fm1];
        
        
        //还可以把id表示的对象传入，前提是确保这个对象是合适的
        //obj1是一个id对象，但已知其实体是一个MobilePhone对象
        [person dialNumber:@"8888888" usingPhone:obj1];
        
        
        //4.动态判断对象的真实类型
        
        //4.1.判断一个对象是否为某个类或者某个类的子类
        
        if ( [obj1 isKindOfClass:[Phone class]] )
        {
            NSLog(@"obj1 is kind of Phone");
            
            //确定类型之后，为了使用方便，可以使用明确的指针类型接收
            Phone *p3 = obj1;
        }
        
        
        //4.2.动态判断一个对象是否为某种具体的类型（不考虑子类）
        
        //已知p2本质是FaxMachine
        
        if ([p2 isMemberOfClass:[Phone class]])
        {
            NSLog(@"p2 is a Phone");
        }
        
        
        if ([p2 isMemberOfClass:[FaxMachine class]])
        {
            NSLog(@"p2 is a FaxMachine");
            
            //确定类型后，为了能使用子类特有的方法，可以用一个子类指针接收这个对象
            FaxMachine *fm2 = (FaxMachine*)p2;
            
            [fm2 sendFax:@"hahah" toNumber:@"110"];
        }
        
        
        
        
        
        
        
        
        
        
        
    }
    return 0;
}

