//
//  Person.m
//  OC_3_2
//
//  Created by Ibokan_Teacher on 15/8/19.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import "Person.h"

//这里需要调用Phone类的方法，则必须引入头文件
#import "Phone.h"

@implementation Person

- (void)dialNumber:(NSString *)number usingPhone:(Phone *)phone
{
    NSLog(@"%@ is dialing", self.name);
    [phone dial:number];
}

@end







