//
//  Person.h
//  OC_3_2
//
//  Created by Ibokan_Teacher on 15/8/19.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>

//@class 类名: 让这个文件中知道有这么一个类的存在，但不知道这个类的方法

@class Phone;

@interface Person : NSObject

@property(nonatomic,copy)NSString *name;

//使用电话进行拨号的方法
- (void)dialNumber:(NSString*)number
        usingPhone:(Phone*)phone;

@end






