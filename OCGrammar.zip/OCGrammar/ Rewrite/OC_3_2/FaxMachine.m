//
//  FaxMachine.m
//  OC_3_2
//
//  Created by Ibokan_Teacher on 15/8/19.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import "FaxMachine.h"

@implementation FaxMachine

- (void)sendFax:(NSString *)fax toNumber:(NSString *)number
{
    [self dial:number];
    
    NSLog(@"send fax: %@", fax);
}

//重写拨号方法增加信息输出
- (void)dial:(NSString *)number
{
    //功能与父类一致
    [super dial:number];
    NSLog(@"fax machine dial");
}


@end







