//
//  FaxMachine.h
//  OC_3_2
//
//  Created by Ibokan_Teacher on 15/8/19.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import "Phone.h"

@interface FaxMachine : Phone

//发传真功能
- (void)sendFax:(NSString*)fax
       toNumber:(NSString*)number;

@end







