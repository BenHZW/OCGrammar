//
//  MobilePhone.h
//  OC_3_2
//
//  Created by Ibokan_Teacher on 15/8/19.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import "Phone.h"

@interface MobilePhone : Phone

//增加发短信功能
- (void)sendSMS:(NSString*)sms
       toNumber:(NSString*)number;

@end








