//
//  main.m
//  OC_6_1
//
//  Created by Ibokan_Teacher on 15/8/24.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>


struct Complex
{
    double a, b;
};
typedef struct Complex Complex;


int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        //1.NSNumber类，把基本数据类型封装成对象
        NSInteger i1 = 63;
        double pi = 3.1415926;
        BOOL isMale = YES;
        
        
       NSNumber *n1 = [[NSNumber alloc] initWithInteger:i1];
        
//        NSNumber *n100 = [NSNumber numberWithInteger:i1];
        NSNumber *n2 = [NSNumber numberWithDouble:pi];
        
        NSNumber *n3 = [NSNumber numberWithBool:isMale];
        
        //简化写法:等效于便利构造器
        NSNumber *n4 = @(1 + 2);
        NSNumber *n5 = @100.1;
        NSNumber *n6 = @NO;
        
        
        //数值比较
        NSNumber *n7 = @NO;
        
        //指针比较
        NSLog(@"n6 == n7 ? %d", n6 == n7);
        
        //数值的具体值比较
        NSLog(@"n4 compare n5: %ld",[n4 compare:n5]);
        
        
        //解封装
        NSInteger i2 = [n1 integerValue];
        double d2 = [n2 doubleValue];
        //其他以此类推
        
        
        //2.NSValue
        
        //2.1.封装自定义结构体
        Complex cpx1 = { 4, 3 };
        
        NSValue *v1 = [NSValue valueWithBytes:&cpx1 objCType:@encode(Complex)];
        //@encode()能够根据填入的类型生成一个对应的C语言字符串
        
        
        //解封装
        Complex cpx2;
        [v1 getValue:&cpx2];
        
        
        //2.2.封装系统定义的结构体
        NSRange range1 = { 0, 3 };
        range1.length = 1;
        range1.location = 4;
        
        NSValue *v2 = [NSValue valueWithRange:range1];
        
        
        //解封装
        NSRange range2 = [v2 rangeValue];
        
        
        //3.代表空指针的对象
        //其本质只是用于表示空指针，但并非空指针
        NSNull *nullObj = [NSNull null];
        
        
#warning 以上所有对象可以直接打印出结果
        
        
    }
    return 0;
}









