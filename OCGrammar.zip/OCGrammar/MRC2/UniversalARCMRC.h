//
//  UniversalARCMRC.h
//  OC_7_2
//
//  Created by Ibokan_Teacher on 15/8/26.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>

//在ARC和MRC环境均可通用，不用加标记的类

@interface UniversalARCMRC : NSObject

@property(nonatomic,retain)NSNumber *number;

@end












