//
//  UniversalARCMRC.m
//  OC_7_2
//
//  Created by Ibokan_Teacher on 15/8/26.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import "UniversalARCMRC.h"

@implementation UniversalARCMRC

@synthesize number = _number;

- (void)setNumber:(NSNumber *)number
{
    if ([number integerValue] > 0)
    {
        
        //前两步只有在MRC环境下才做
#if !__has_feature(objc_arc)
        [number retain];
        
        [_number release];
#endif
        
        _number = number;
    }
}


//只有在MRC环境下才有必要重写dealloc
#if !__has_feature(objc_arc)
- (void)dealloc
{
    [_number release];
    [super dealloc];
}
#endif



@end









