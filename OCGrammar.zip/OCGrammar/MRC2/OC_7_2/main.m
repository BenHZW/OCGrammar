//
//  main.m
//  OC_7_2
//
//  Created by Ibokan_Teacher on 15/8/26.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Student.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        
        //1.在ARC项目中使用MRC写的类
        //要为MRC写的m文件添加标记
        //-fno-objc-arc
        
        Student *stu1 = [[Student alloc] initWithName:@"FFGG" age:10 number:@8];
        
        //ARC下也可以看retainCount
        NSLog(@"stu1.retainCount:%lu", CFGetRetainCount((__bridge CFTypeRef)(stu1)));
        
        
        //ARC下默认任何对象都是强引用
        //如果不想使用强引用，则需要在声明的时候加上其他关键字
        
        //比如弱引用关键字：
        __weak Student *stu2 = stu1;
        NSLog(@"stu2.retainCount:%lu", CFGetRetainCount((__bridge CFTypeRef)(stu2)));
        
    }
    return 0;
}





