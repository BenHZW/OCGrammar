//
//  main.m
//  OC_11_1
//
//  Created by Ibokan_Teacher on 15/9/1.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        //1.声明代码块
        void (^printStringBlock)(NSString *) = ^(NSString *str)
        {
            //填写代码块具体执行的代码
            //代码块的代码在声明时并不会执行，必须在后期调用代码块
            NSLog(@"%@", str);
        };
        
        
        //2.调用代码块
        //形式和调用C语言函数类似
        printStringBlock(@"abcde");
        
        
        //3.再举一些例子
        NSInteger (^plusBlock)(NSInteger, NSInteger) = ^(NSInteger a, NSInteger b)
        {
            return a + b;
        };
        
        NSInteger sum = plusBlock( 1, 2 );
        NSLog(@"sum: %ld", sum);
        
        //跟C语言相似，当没有参数时，也要写上()
        
        
        //4.代码块可以使用代码块作用域外层的作用域的变量
        NSInteger i1 = 7;
        void (^block1)() = ^()
        {
            NSLog(@"i1: %ld", i1);
        };
        block1();
        
        
        //如果要在代码块内修改外层变量，则：
        __block NSInteger i2 = 0;
        void (^block2)() = ^()
        {
            i2 = 4;
            NSLog(@"i2: %ld", i2);
        };
        block2();
        NSLog(@"i2:%ld",i2);
        
        //5.使用代码块给数组排序
        NSMutableArray *numberArray = [[NSMutableArray alloc] initWithObjects:@48, @0, @10.9, @-24, nil];
        
        
        //先声明一个能够比较两个对象的代码块
        //NSComparisonResult (^numberCompare)(NSNumber*, NSNumber*);
        NSComparator numberCompare;
        
        numberCompare = ^NSComparisonResult(NSNumber *n1, NSNumber *n2)
        {
            //例如，在这里返回compare方法的结果的相反数
            return -[n1 compare:n2];
        };
        
        
        
        [numberArray sortUsingComparator:numberCompare];
        
        NSLog(@"numberArray: %@", numberArray);
        
        
        //代码块作为参数时，可以直接代入实体，不必额外声明代码块
        [numberArray sortUsingComparator:^NSComparisonResult(NSNumber *n1, NSNumber *n2) {
            return [n1 compare:n2];
        }];
        
        NSLog(@"numberArray: %@", numberArray);
        
        
    }
    return 0;
}





