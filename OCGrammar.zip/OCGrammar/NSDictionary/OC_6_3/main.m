//
//  main.m
//  OC_6_3
//
//  Created by Ibokan_Teacher on 15/8/24.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{
    
    @autoreleasepool {
        
        //1.不可变字典NSDictionary
        
        //1.1.创建
        //这个方法中，按照对象,键,对象,键...
        NSDictionary *dic1 = [[NSDictionary alloc] initWithObjectsAndKeys:@1, @"一", @5, @"目", @5, @"田", @7, @"我", nil];
        //最后以nil结束
        
        
        //简便写法：只能表示不可变字典
        //等效于便利构造器
        //填写顺序是键:对象,键:对象,...
        NSDictionary *dic2 = @{@"me": @2, @"him": @3, @"dictionary": @10};
        
        
        //1.2.访问字典
        
        //获得字典中索引的数量（key的数量）
        NSLog(@"dic2.count: %lu", dic2.count);
        
        
        //根据key找到对应的object
        NSNumber *n1 = [dic1 objectForKey:@"目"];
        NSLog(@"n1: %@", n1);
        
        NSNumber *n2 = dic2[@"me"];
        NSLog(@"n2: %@", n2);
        
        
        //字典整个打印
        NSLog(@"dic2: %@", dic2);
        
        
        //获得字典的所有key
        //返回的keys也是无序的
        NSArray *dic1AllKeys = [dic1 allKeys];
        
        //1.3.for-in循环遍历字典
        for (NSString *aKey in dic2)
        {
            //每轮循环都将字典中的key逐个赋值给aKey
            NSLog(@"dic2[%@]: %@", aKey, dic2[aKey]);
        }
        
        
        //2.可变字典NSMutableDictionary
        //继承于不可变字典，所以……
        
        NSMutableDictionary *mdic1 = [NSMutableDictionary new];
        
        
        //2.1.增加/修改索引关系
        [mdic1 setObject:@100 forKey:@"满意度"];
        //[mdic1 setObject:@5 forKey:@"满意度"];
        mdic1[@"满意度"] = @5;
        
        
        //2.2.删除索引关系
        [mdic1 removeObjectForKey:@"满意度"];
        
        
    }
    return 0;
}








