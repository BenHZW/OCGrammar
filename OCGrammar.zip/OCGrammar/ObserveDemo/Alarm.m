//
//  Alarm.m
//  OC-12-Homework
//
//  Created by Ibokan on 14-12-3.
//  Copyright (c) 2014年 fghf. All rights reserved.
//

#import "Alarm.h"
#import "Dam.h"

@interface Alarm ()
{
    //被观察者应该是弱引用
    __weak Dam *_dam;
}
@end

@implementation Alarm

- (id)initWithDam:(Dam *)dam
{
    self = [super init];
    if (self)
    {
        _dam = dam;
        [_dam addObserver:self forKeyPath:@"waterLevel" options:NSKeyValueObservingOptionNew context:nil];
    }
    return self;
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
    //获取最新水位
    NSNumber *waterLevelNumber = [change objectForKey:NSKeyValueChangeNewKey];
    
    CGFloat waterLevel = [waterLevelNumber floatValue];
    
    //判断水位
    if (waterLevel > 80)
        NSLog(@"警告，水位超高，当前水位:%f", waterLevel);
    
    else if (waterLevel < 50)
        NSLog(@"警告，水位过低，当前水位:%f", waterLevel);
    
    else //正常情况
        NSLog(@"水位正常，当前水位:%f", waterLevel);
    
}

- (void)dealloc
{
    [_dam removeObserver:self forKeyPath:@"waterLevel"];
}

@end










