//
//  Dam.m
//  OC-12-Homework
//
//  Created by Ibokan on 14-12-3.
//  Copyright (c) 2014年 fghf. All rights reserved.
//

#import "Dam.h"

@interface Dam ()
//可以在延展声明私有的setter
//也可以不声明，直接实现
- (void)setWaterLevel:(CGFloat)waterLevel;
@end

@implementation Dam

- (void)setWaterLevel:(CGFloat)waterLevel
{
    _waterLevel = waterLevel;
}

- (void)waterLevelUp:(CGFloat)meters
{
    //使用实例变量进行运算，不会触发KVO
    //_waterLevel += meters;
    
    //要想KVO起作用，就需要用标准的setter或者使用KVC赋值
    self.waterLevel += meters;
}

- (void)waterLevelDown:(CGFloat)meters
{
    //使用实例变量进行运算，不会触发KVO
    
    //要想KVO起作用，就需要用标准的setter或者使用KVC赋值
    if (self.waterLevel - meters >= 0)
    {
        //_waterLevel -= meters;
        self.waterLevel -= meters;
    }
}

@end





