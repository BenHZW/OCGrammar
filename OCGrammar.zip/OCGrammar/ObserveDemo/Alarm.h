//
//  Alarm.h
//  OC-12-Homework
//
//  Created by Ibokan on 14-12-3.
//  Copyright (c) 2014年 fghf. All rights reserved.
//

#import <Foundation/Foundation.h>
@class Dam;
@interface Alarm : NSObject

//便利初始化方法里面指定观察的对象
- (id)initWithDam:(Dam *)dam;

@end




