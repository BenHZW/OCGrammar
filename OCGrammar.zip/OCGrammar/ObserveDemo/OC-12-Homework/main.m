//
//  main.m
//  OC-12-Homework
//
//  Created by Ibokan on 14-12-3.
//  Copyright (c) 2014年 fghf. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Dam.h"
#import "Alarm.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        Dam *dam = [Dam new];
        
        Alarm *alarm = [[Alarm alloc] initWithDam:dam];
        
        [dam waterLevelUp:40];
        
        [dam waterLevelUp:30];
        
        [dam waterLevelUp:20];
        
        [dam waterLevelDown:30];
        
    }
    return 0;
}

