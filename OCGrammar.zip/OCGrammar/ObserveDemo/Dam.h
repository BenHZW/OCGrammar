//
//  Dam.h
//  OC-12-Homework
//
//  Created by Ibokan on 14-12-3.
//  Copyright (c) 2014年 fghf. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Dam : NSObject

//水位增加和减少的方法
- (void)waterLevelUp:(CGFloat)meters;

- (void)waterLevelDown:(CGFloat)meters;

//水位属性，设计为只读
@property(nonatomic, readonly)CGFloat waterLevel;

@end




