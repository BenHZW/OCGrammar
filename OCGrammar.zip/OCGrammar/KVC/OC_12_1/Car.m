//
//  Car.m
//  OC_4
//
//  Created by Ibokan_Teacher on 15/8/20.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import "Car.h"
#import "Tyre.h"
#import "Engine.h"

//空对象的宏定义
#define nullObject [NSNull null]

@implementation Car

- (void)setTyre:(Tyre *)tyre atIndex:(NSUInteger)index
{
    //判断下标合法性
    if (index <= 3)
    {
        //判断传进来的轮胎是否为nil
        if (tyre == nil)
            _tyres[index] = nullObject;

        else
            _tyres[index] = tyre;
    }
}

- (Tyre *)tyreAtIndex:(NSUInteger)index
{
    //检查下标合法性
    if (index <= 3)
    {
        Tyre *aTyre = _tyres[index];
        
        //判断是否为空对象
        if ([aTyre isEqualTo:nullObject])
            return nil;
        else
            return aTyre;

        
    }
    else
    {
        //下标不合法则返回空指针
        return nil;
    }
}

- (NSString *)description
{
    return [NSString stringWithFormat:@"Car: %@\nEngine:%@\nTyres: %@,%@,%@,%@", self.brand, self.engine, _tyres[0], _tyres[1], _tyres[2], _tyres[3]];
}


- (instancetype)init
{
    self = [super init];
    if (self)
    {
        //初始化轮胎数组
        _tyres = [[NSMutableArray alloc] initWithObjects:nullObject, nullObject, nullObject, nullObject, nil];
    }
    return self;
}


#if !__has_feature(objc_arc)
- (void)dealloc
{
    //释放轮胎
    [_tyres release];
    
    //释放引擎
    [_engine release];
    
    
    //释放汽车品牌
    [_brand release];
    
    
    [super dealloc];
    
}
#endif


@end








