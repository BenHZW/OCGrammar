//
//  main.m
//  OC_12_1
//
//  Created by Ibokan_Teacher on 15/9/6.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Engine.h"
#import "Tyre.h"
#import "Car.h"


int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        
        //1.KVC的简单使用
        
        Engine *engine1 = [Engine new];
        
        //用KVC给引擎的品牌赋值
        [engine1 setValue:@"We Try" forKey:@"brand"];
        
        Tyre *tyre1 = [Tyre new];
        Tyre *tyre2 = [Tyre new];
        Tyre *tyre3 = [Tyre new];
        Tyre *tyre4 = [Tyre new];
        
        
        //用KVC给轮胎品牌赋值
        [tyre1 setValue:@"A" forKey:@"brand"];
        [tyre2 setValue:@"B" forKey:@"brand"];
        [tyre3 setValue:@"C" forKey:@"brand"];
        [tyre4 setValue:@"D" forKey:@"brand"];
        
        
        //通过KVC获得对象的属性
        NSString *engine1Brand = [engine1 valueForKey:@"brand"];
        NSString *tyre1Brand = [tyre1 valueForKey:@"brand"];
        
        NSLog(@"engine1Brand: %@", engine1Brand);
        NSLog(@"tyre1Brand: %@", tyre1Brand);
        
        
        //安装引擎
        Car *car1 = [Car new];
        [car1 setValue:engine1 forKey:@"engine"];
        
        
        //安装轮胎
        //用KVC甚至能访问protected的实例变量，但一般不建议这样做
        NSMutableArray *tyres = [[NSMutableArray alloc] initWithObjects:tyre1, tyre2, tyre3, tyre4, nil];
        
        [car1 setValue:tyres forKey:@"_tyres"];
        
        
        //如果属性是基本数据类型，则set和get的时候都用的是NSValue或NSNumber
        [tyre1 setValue:@12 forKey:@"pressure"];
        [tyre2 setValue:@10 forKey:@"pressure"];
        [tyre3 setValue:@20 forKey:@"pressure"];
        [tyre4 setValue:@40 forKey:@"pressure"];
        
        NSNumber *tyre2Pressure = [tyre2 valueForKey:@"pressure"];
        NSLog(@"tyre2Pressure: %@", tyre2Pressure);
        
        
        //2.键值路径的使用
        NSString *carEngineBrand = [car1 valueForKeyPath:@"engine.brand"];
        NSLog(@"carEngineBrand: %@", carEngineBrand);
        //setValue: forKeyPath:留待大家实践
        
        
        //3.填入不正确的键值路径
        [tyre2 setValue:@41 forKeyPath:@"presure"];
        
        NSLog(@"tyre3 pressure: %@", [tyre3 valueForKeyPath:@"presure"]);
        
        
        //4.使用KVC把数组中的对象的属性集中提取
        NSArray *tyreBrands = [car1 valueForKeyPath:@"_tyres.brand"];
        NSLog(@"tyreBrands: %@", tyreBrands);
        
        
        //5.KVC对容器的统计功能
        
        //获取数组元素的个数
        NSNumber *tyreCount = [car1 valueForKeyPath:@"_tyres.@count"];
        NSLog(@"tyreCount: %@", tyreCount);
        
        //求出数组元素的某个属性值的和、最大值、最小值、平均值
        NSNumber *tyreMaxPressure = [car1 valueForKeyPath:@"_tyres.@max.pressure"];
        NSNumber *tyreAvgPressure = [car1 valueForKeyPath:@"_tyres.@avg.pressure"];
        
        NSLog(@"tyreMaxPressure: %@", tyreMaxPressure);
        NSLog(@"tyreAvgPressure: %@", tyreAvgPressure);
        
        
        
    }
    return 0;
    
    
}



