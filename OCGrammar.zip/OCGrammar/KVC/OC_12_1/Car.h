//
//  Car.h
//  OC_4
//
//  Created by Ibokan_Teacher on 15/8/20.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>

@class Tyre, Engine;

@interface Car : NSObject

//汽车不是汽车零件的其中一种，不继承于任何汽车零件
{
    //用可变数组存储轮胎
    NSMutableArray *_tyres;
}

//汽车品牌
@property(nonatomic,copy)NSString *brand;

//引擎：要使用强引用
@property(nonatomic,retain)Engine *engine;


//轮胎的setter和getter
- (void)setTyre:(Tyre*)tyre
        atIndex:(NSUInteger)index;

- (Tyre*)tyreAtIndex:(NSUInteger)index;


@end











