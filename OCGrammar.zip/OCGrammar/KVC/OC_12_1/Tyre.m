//
//  Tyre.m
//  OC_4
//
//  Created by Ibokan_Teacher on 15/8/20.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import "Tyre.h"

@implementation Tyre

- (NSString *)description
{
    return [NSString stringWithFormat:@"Tyre: %@", [super description]];
}


//重写处理不存在的键值路径的方法
- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    NSLog(@"key \"%@\" undefined, can't be set", key);
}

- (id)valueForUndefinedKey:(NSString *)key
{
    NSLog(@"key \"%@\" undefined, get nothing", key);
    return nil;
}


@end








