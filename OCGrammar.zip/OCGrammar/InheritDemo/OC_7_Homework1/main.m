//
//  main.m
//  OC_4
//
//  Created by Ibokan_Teacher on 15/8/20.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Car.h"
#import "Engine.h"
#import "Tyre.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        //1.创建引擎
        Engine *engine1 = [Engine new];
        engine1.brand = @"康明斯";
        
        
        //2.创建轮胎
        Tyre *tyre1 = [Tyre new];
        tyre1.brand = @"韩泰";
        
        
        //3.创建汽车
        Car *car1 = [Car new];
        car1.brand = @"大众";
        
        //组装
        car1.engine = engine1;
        [engine1 release];
        
        
        [car1 setTyre:tyre1 atIndex:0];
        [tyre1 release];
        
        
        
        [car1 release];
        
    }
    return 0;
}

