//
//  Car.m
//  OC_4
//
//  Created by Ibokan_Teacher on 15/8/20.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import "Car.h"
#import "Tyre.h"
#import "Engine.h"

@implementation Car

- (void)setTyre:(Tyre *)tyre atIndex:(NSUInteger)index
{
    //判断下标合法性
    if (index <= 3)
    {
#if !__has_feature(objc_arc)
        [tyre retain];
        
        [_tyres[index] release];
#endif
        _tyres[index] = tyre;
    }
}

- (Tyre *)tyreAtIndex:(NSUInteger)index
{
    //检查下标合法性
    if (index <= 3)
    {
        return _tyres[index];
    }
    else
    {
        //下标不合法则返回空指针
        return nil;
    }
}

- (NSString *)description
{
    return [NSString stringWithFormat:@"Car: %@\nEngine:%@\nTyres: %@,%@,%@,%@", self.brand, self.engine, _tyres[0], _tyres[1], _tyres[2], _tyres[3]];
}

#if !__has_feature(objc_arc)
- (void)dealloc
{
    //释放轮胎
    for (int i = 0; i < 4; ++i)
    {
        [_tyres[i] release];
    }
    
    //释放引擎
    [_engine release];
    
    
    //释放汽车品牌
    [_brand release];
    
    
    [super dealloc];
    
}
#endif


@end








