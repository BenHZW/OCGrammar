//
//  CarItem.m
//  OC_4
//
//  Created by Ibokan_Teacher on 15/8/20.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import "CarItem.h"

@implementation CarItem

#pragma mark - 重写description方法

- (NSString *)description
{
    return self.brand;
}


#if !__has_feature(objc_arc)
- (void)dealloc
{
    [_brand release];
    [super dealloc];
}
#endif


@end






