//
//  CarItem.h
//  OC_4
//
//  Created by Ibokan_Teacher on 15/8/20.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CarItem : NSObject

//品牌
@property(nonatomic, copy)NSString *brand;

@end







