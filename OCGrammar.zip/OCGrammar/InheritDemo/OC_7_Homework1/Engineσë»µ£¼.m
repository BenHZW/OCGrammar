//
//  Engine.m
//  OC_4
//
//  Created by Ibokan_Teacher on 15/8/20.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import "Engine.h"

@implementation Engine

- (NSString *)description
{
    return [NSString stringWithFormat:@"Engine: %@", [super description]];
}

@end








