//
//  Rectangle.m
//  OC_3_1
//
//  Created by Ibokan_Teacher on 15/8/19.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import "Rectangle.h"

@implementation Rectangle

#pragma mark - 实现便利初始化方法
- (id)initWithLength:(CGFloat)length width:(CGFloat)width
{
    //在初始化自身之前先调用父类的初始化方法，将父类中必须的初始化行为先完成，确保子类能正常工作
    if (self = [super init])
    {
        _length = length;
        _width = width;
    }
    return self;
}

#pragma mark - 重写（覆盖）继承自父类的方法
- (CGFloat)area
{
    return self.length * self.width;
}

@end








