//
//  Company.m
//  OC_6_Homework
//
//  Created by Ibokan_Teacher on 15/8/25.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import "Company.h"
#import "Boss.h"

@implementation Company

-(id)initWithBoss:(Boss *)boss money:(NSInteger)money
{
    if (self = [super init])
    {
        _boss = boss;
        _money = money;
    }
    return self;
}


- (NSString *)description
{
    return [NSString stringWithFormat:@"boss: %@, money: %ld", self.boss.name, self.money];
}


@end







