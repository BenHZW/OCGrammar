//
//  Company.h
//  OC_6_Homework
//
//  Created by Ibokan_Teacher on 15/8/25.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>
@class Boss;

@interface Company : NSObject

@property(nonatomic)Boss *boss;

@property(nonatomic)NSInteger money;

-(id)initWithBoss:(Boss*)boss
            money:(NSInteger)money;

@end






