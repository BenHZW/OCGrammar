//
//  Square.m
//  OC_3_1
//
//  Created by Ibokan_Teacher on 15/8/19.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import "Square.h"

@implementation Square

#pragma mark - 重写父类的便利初始化方法
- (id)initWithLength:(CGFloat)length width:(CGFloat)width
{
    //调用父类的初始化方法
    //填入相等的长宽参数，即达到保证长宽相等的目的
    self = [super initWithLength:length width:length];
    
    //if语句可省略
    
    return self;
}


#pragma mark - 实现自己的便利初始化方法
- (id)initWithLength:(CGFloat)length
{
    //可直接利用自己的便利初始化方法
    //在这里面已经包含了调用父类初始化方法的过程
    self = [self initWithLength:length width:length];
    
    /*
    if (self)
    {
        //不需要做其他操作
    }
     */
    
    return self;
    
}


#pragma mark - 重写长宽的setter
//保证长宽严格相等

- (void)setLength:(CGFloat)length
{
    //1.设置长的值，这个过程和父类相同
    //调用父类的方法
    [super setLength:length];
    
    //2.同时设置宽的值跟长相同
    //选用父类的方法进行设置
    [super setWidth:length];
    
}


- (void)setWidth:(CGFloat)width
{
    //原理同上
    [super setWidth:width];
    
    [super setLength:width];
}


//计算面积的方法
//做法与矩形完全相同，不必重写


@end






