//
//  Boss.h
//  OC_6_Homework
//
//  Created by Ibokan_Teacher on 15/8/25.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Boss : NSObject

@property(nonatomic,copy)NSString *name;

//标准compare方法
- (NSComparisonResult)compare:(Boss*)anotherBoss;


- (id)initWithName:(NSString*)name;


@end






