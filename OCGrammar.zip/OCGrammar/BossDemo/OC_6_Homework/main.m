//
//  main.m
//  OC_6_Homework
//
//  Created by Ibokan_Teacher on 15/8/25.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Square.h"
#import "Rectangle.h"

#import "Company.h"
#import "Boss.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
#pragma mark - 第1题
        Rectangle *rtg1 = [[Rectangle alloc] initWithLength:8 width:6];
        Square *sqr1 = [[Square alloc] initWithLength:7];
        Rectangle *rtg2 = [[Rectangle alloc] initWithLength:5 width:6];
        
        NSMutableArray *shapes = [NSMutableArray arrayWithObjects:rtg1, sqr1, rtg2, nil];
        
        [shapes sortUsingSelector:@selector(compare:)];
        
        NSLog(@"shapes: %@", shapes);
        
        
#pragma mark - 第2题
        //创建Boss
        Boss *boss1 = [[Boss alloc] initWithName:@"Wong"];
        Boss *boss2 = [[Boss alloc] initWithName:@"Choy"];
        
        //创建公司
        Company *company1 = [[Company alloc] initWithBoss:boss1 money:1000];
        
        Company *company2 = [[Company alloc] initWithBoss:boss2 money:2000];
        
        Company *company3 = [[Company alloc] initWithBoss:boss1 money:500];
        
        
        //把三个公司放入数组
        NSMutableArray *companies = [NSMutableArray arrayWithArray:@[company1, company2, company3]];
        
        //创建两个排序描述器
        NSSortDescriptor *bossDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"boss" ascending:YES];
        
        NSSortDescriptor *moneyDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"money" ascending:YES];
        
        
        //排序
        [companies sortUsingDescriptors:@[bossDescriptor, moneyDescriptor]];
        
        NSLog(@"companies: %@", companies);
        
        
#pragma mark - 第3题
        NSString *expression = @"1+10-200-6";
        
        //创建含有+-号的字符集
        NSCharacterSet *plusMinusSet = [NSCharacterSet characterSetWithCharactersInString:@"+-"];
        
        //用这个字符集分割字符串
        NSArray *numbers = [expression componentsSeparatedByCharactersInSet:plusMinusSet];
        
        
        //用于求和的变量
        NSInteger sum = [numbers.firstObject integerValue];
        
        
        //记录当前要参与运算的数字字符串的下标
        NSUInteger numberIndex = 1;
        
        
        //逐个字符进行查找
        for (NSInteger i = 0; i < expression.length; ++i)
        {
            //以字符串的形式提取单个字符
            NSString *c = [expression substringWithRange:NSMakeRange(i, 1)];
            
            //如果是+
            if ([c compare:@"+"] == 0)
            {
                //进行加法
                sum += [numbers[numberIndex++] integerValue];
                //++numberIndex;
            }
            //如果是-
            else if ([c compare:@"-"] == 0)
            {
                //进行减法
                sum -= [numbers[numberIndex++] integerValue];
            }
            
        }
        
        
        NSLog(@"sum: %ld", sum);
        
        
        
        
        
    }
    return 0;
}








