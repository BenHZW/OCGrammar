//
//  Boss.m
//  OC_6_Homework
//
//  Created by Ibokan_Teacher on 15/8/25.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import "Boss.h"

@implementation Boss

- (NSComparisonResult)compare:(Boss *)anotherBoss
{
    //名字的比较结果就是Boss的比较结果
    return [self.name compare:anotherBoss.name];
}

- (id)initWithName:(NSString *)name
{
    if (self = [super init])
    {
        _name = name;
    }
    return self;
}

@end







