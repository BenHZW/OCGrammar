//
//  Rectangle.h
//  OC_3_1
//
//  Created by Ibokan_Teacher on 15/8/19.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import "Shape.h"

@interface Rectangle : Shape

//子类拥有父类的全部内容（包括属性和方法）
//意味着area方法不需要重复声明


//但是还可以增加自己特有的属性和方法

//矩形的长宽属性
@property(nonatomic)CGFloat length;
@property(nonatomic)CGFloat width;


//增加便利初始化方法
- (id)initWithLength:(CGFloat)length
               width:(CGFloat)width;


@end








