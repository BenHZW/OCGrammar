//
//  Square.h
//  OC_3_1
//
//  Created by Ibokan_Teacher on 15/8/19.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import "Rectangle.h"

@interface Square : Rectangle

//正方形只有“边长”
//增加一个通过边长初始化的方法
- (id)initWithLength:(CGFloat)length;

@end







