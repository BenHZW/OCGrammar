//
//  main.m
//  OC_9_2
//
//  Created by Ibokan_Teacher on 15/8/31.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SomeClass.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        SomeClass *sc = [SomeClass new];
        
        //MRC可以强行调用任何没有声明过的方法
        [sc privateMethod];
        
        
        
    }
    return 0;
}

