//
//  SomeClass.h
//  OC_9_2
//
//  Created by Ibokan_Teacher on 15/8/31.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SomeClass : NSObject

@end





