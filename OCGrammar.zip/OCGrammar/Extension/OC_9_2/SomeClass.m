//
//  SomeClass.m
//  OC_9_2
//
//  Created by Ibokan_Teacher on 15/8/31.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import "SomeClass.h"

//延展通常用来在m文件内声明实例变量
@interface SomeClass ()
{
    NSInteger _someInt;
}

//如果想要找个位置声明私有方法，则在延展里声明
- (void)privateMethod;

@end



@implementation SomeClass

//只在m文件写实现不在头文件声明的方法，都可以达到“私有方法”的效果
- (void)privateMethod
{
    NSLog(@"私有方法");
}

@end








