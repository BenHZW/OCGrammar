//
//  Time.h
//  OCSample
//
//  Created by CJJMac on 14-12-16.
//  Copyright (c) 2014年 CJJMac. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Time : NSObject

//时分秒三个属性
//数据类型采用NSUInteger无符号型，因为这三个值不可能是负数
@property(nonatomic)NSUInteger hour;
@property(nonatomic)NSUInteger minute;
@property(nonatomic)NSUInteger second;


//便利初始化方法
- (id)initWithHour:(NSUInteger)hour
            minute:(NSUInteger)minute
            second:(NSUInteger)second;


//一次过设置时分秒的方法
- (void)setHour:(NSUInteger)hour
         minute:(NSUInteger)minute
         second:(NSUInteger)second;


//时间增减方法


//时间增加1秒的方法
- (void)increaseOneSecond;

//时间减少1秒的方法
//返回值为BOOL型，表示运算是否成功
- (BOOL)decreaseOneSecond;


//时间增加1分钟的方法
- (void)increaseOneMinute;


//时间减少1分钟的方法
//返回值为BOOL型，表示运算是否成功
- (BOOL)decreaseOneMinute;



@end
