//
//  main.m
//  TimeClass
//
//  Created by Ibokan_Teacher on 15/9/2.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "Time.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        Time *t1 = [[Time alloc] initWithHour:8 minute:60 second:70];
        NSLog(@"t1: %@", t1);
        
    }
    return 0;
}

