//
//  Time.m
//  OCSample
//
//  Created by CJJMac on 14-12-16.
//  Copyright (c) 2014年 CJJMac. All rights reserved.
//

#import "Time.h"


@interface Time ()

//分、秒有效值判断的辅助方法
+ (NSUInteger)getEffectiveMinuteOrSecond:(NSUInteger)value;

@end



@implementation Time

- (id)initWithHour:(NSUInteger)hour minute:(NSUInteger)minute second:(NSUInteger)second
{
    self = [super init];
    
    if (self)
    {
        _hour = hour;
        
        //分和秒不能超过59，利用条件判断三目运算符，决定赋给分、秒的值
        _minute = minute > 59 ? 59 : minute;
        
        _second = second > 59 ? 59 : second;
    }
    
    return self;
}


#pragma mark - 一次过设置时分秒的方法
- (void)setHour:(NSUInteger)hour minute:(NSUInteger)minute second:(NSUInteger)second
{
    //调用各自的set方法
    self.hour = hour;
    self.minute = minute;
    self.second = second;
}



#pragma mark - 重写分、秒的set方法
//保证其值有效，不会出0~59这个范围
//里面都调用了辅助方法
- (void)setMinute:(NSUInteger)minute
{
    _minute = [Time getEffectiveMinuteOrSecond:minute];
}

- (void)setSecond:(NSUInteger)second
{
    _second = [Time getEffectiveMinuteOrSecond:second];
}

#pragma mark - 分、秒有效值判断的辅助方法
+ (NSUInteger)getEffectiveMinuteOrSecond:(NSUInteger)value
{
    
    //判断传入的值，防止其值超过59
    if (value > 59)
    {
        
        //特别地，当传入参数为60时，返回值为0
        if (value == 60)
            return 0;
        else
            return 59;
    }
    
    else
        return value;
}


#pragma mark - 时间增加或减少1分的方法
//要考虑对小时的影响

- (void)increaseOneMinute
{
    //如果当前分已经是59，那么小时要加1
    if (self.minute == 59)
        self.hour += 1;
    
    //最后分还是要自增1
    //调用分的set方法，可以很方便地加1计算，不会超出范围
    self.minute += 1;
}

- (BOOL)decreaseOneMinute
{
    
    //如果当前分是0，那么要考虑：
    if (self.minute == 0)
    {
        //如果小时也是0，那么分就无法减了
        if (self.hour == 0)
            //直接返回NO，表示无法自减
            return NO;
        
        
        //如果小时不是0，那么小时要减1
        else
            self.hour -= 1;
    }
    
    //无论如何最后分还是要自减1
    //调用分的set方法，可以很方便地减1计算，不会超出范围
    self.minute -= 1;
    
    return YES;
}



#pragma mark - 时间增加或减少1秒的方法
//要考虑对分的影响

- (void)increaseOneSecond
{
    //如果当前秒为59
    if (self.second == 59)
    {
        //那么要考虑自增1分钟
        //直接调用已有的方法
        [self increaseOneMinute];
        //该方法已经考虑了自增1分中对小时的影响，我们在这里就不用关心了
    }
    
    //最后还是要秒自增1
    //同样调秒的set方法
    self.second += 1;
}


- (BOOL)decreaseOneSecond
{
    //如果当前秒已经是0，那么要考虑：
    if (self.second == 0)
    {
        //应该要让分也减1
        
        //那就要看看分自减1能否成功
        //如果分自减失败
        if ([self decreaseOneMinute] == NO)
        {
            //那么秒也无法自减了
            //直接返回NO表示失败
            return NO;
        }
    }
    
    
    //最后秒还是要自减1
    //使用set方法设置
    self.second -= 1;
    
    return YES;
}


#pragma mark - 重写description方法
//为了方便调试输出
- (NSString *)description
{
    return [NSString stringWithFormat:@"%lu:%lu:%lu", self.hour, self.minute, self.second];
}


@end
