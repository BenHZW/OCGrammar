//
//  main.m
//  OC_2_2
//
//  Created by Ibokan_Teacher on 15/8/17.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Teacher.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        //1.实例化一个Teacher对象
        Teacher *t1 = [[Teacher alloc] init];
        
        //2.使用setter和getter访问对象的实例变量
        [t1 setName:@"HHH"];
        [t1 setAge:12];
        [t1 setIsMarried:NO];
        
        
        NSString *t1Name = [t1 name];
        NSInteger t1Age = [t1 age];
        
        
        //对于合符规范的setter和getter还能用点语法去调用
        
        //这种点语法出现在赋值运算符左边时或者进行自增自减运算时是setter
        t1.isMarried = YES;
        
        //其他情况均为getter
        NSLog(@"t1{ name:%@, age:%ld, isMarried:%d", t1Name, t1Age, t1.isMarried);
        
        
        //3.使用便利初始化方法
        Teacher *t2 = [[Teacher alloc] initWithName:@"OOO" age:50 isMarried:YES];
        NSLog(@"t2:{ name:%@, age:%ld, isMarried:%d }", t2.name, t2.age, t2.isMarried);
        
        
        //4.使用便利构造器
        Teacher *t3 = [Teacher teacherWithName:@"BCD" age:5 isMarried:NO];
        
        
        //5.使用“属性”
        [t3 setIsMale:YES];
        NSLog(@"t3 is male ? %d", t3.isMale);
        
        
    }
    return 0;
}






