//
//  main.m
//  OC_6_4
//
//  Created by Ibokan_Teacher on 15/8/24.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        //1.不可变集合NSSet
        //这个是数学意义上的集合：无序、不允许出现重复元素
        
        NSSet *set1 = [[NSSet alloc] initWithObjects:@0, @1, @2, @3, nil];
        NSSet *set2 = [NSSet setWithObjects:@0, @-1, @-2, @-3, nil];
        
        //1.1.访问
        NSLog(@"set1: %@", set1);
        NSLog(@"set2: %@", set2);
        
        
        //“随机”取出集合中的一个元素
        NSNumber *n1 = [set1 anyObject];
        NSLog(@"n1: %@", n1);
        
        
        //取出全部元素
        NSArray *set2AllObjects = [set2 allObjects];
        
        //用for-in循环遍历集合，用法与数组类似，但无序，请填坑
        
        
        
        //2.可变集合NSMutableSet
        NSMutableSet *mset1 = [NSMutableSet setWithSet:set1];
        NSMutableSet *mset2 = [NSMutableSet setWithSet:set2];
        
        //2.1.求交集（会直接修改调用求交集方法的集合）
        [mset1 intersectSet:mset2];
        NSLog(@"mset1: %@", mset1);
        
        
        //2.2.求并集（直接修改调用方法的集合）
        [mset1 unionSet:mset2];
        NSLog(@"mset1: %@", mset1);
        
        NSLog(@"111111111");
        
        NSMutableSet *mset3 = [NSMutableSet setWithSet:set1];
        [mset3 minusSet:mset2];
        NSLog(@"mset1:%@",mset1);
        
    }
    return 0;
}






