//
//  NSString+GetRanges.h
//  OC-9-Homework1
//
//  Created by Ibokan on 14-11-27.
//  Copyright (c) 2014年 fghf. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (GetRanges)

- (NSArray*)rangesOfString:(NSString *)aString;

@end






