//
//  main.m
//  OC_9_Homework2
//
//  Created by Ibokan_Teacher on 15-4-23.
//  Copyright (c) 2015年 fghf. All rights reserved.
//


#import <Foundation/Foundation.h>
#import "NSString+GetRanges.h"
#import "NSDate+GetComponents.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        //2.使用-rangesOfString方法
        NSString *str = @"类目并不高深，类目可以为现有的类增加方法，这些方法写起来跟不用类目时的写法是相通的。";
        NSArray *ranges = [str rangesOfString:@"类目"];
        NSLog(@"ranges: %@", ranges);
        
        
        //3.使用-getComponentsByTimeZone方法
        NSTimeZone *tz = [NSTimeZone timeZoneWithName:@"Egypt"];
        NSDate *date = [NSDate date];
        
        NSDateComponents *components = [date getComponentsByTimeZone:tz];
        NSLog(@"%@", components);
        
    }
    return 0;
}

