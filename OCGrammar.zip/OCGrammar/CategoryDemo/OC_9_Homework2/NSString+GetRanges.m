//
//  NSString+GetRanges.m
//  OC-9-Homework1
//
//  Created by Ibokan on 14-11-27.
//  Copyright (c) 2014年 fghf. All rights reserved.
//

#import "NSString+GetRanges.h"

@implementation NSString (GetRanges)

- (NSArray *)rangesOfString:(NSString *)aString
{
    //创建一个数组存放这些range
    NSMutableArray *ranges = [NSMutableArray array];
    
    //用于确定搜索范围的
    //最初的搜索范围是整个字符串
    NSRange searchRange = { 0, self.length };
    
    //循环找出这些range
    while (YES)
    {
        NSRange foundRange = [self rangeOfString:aString options:0 range:searchRange];
        
        //如果找到一个range就把它放进数组
        if( foundRange.location != NSNotFound )
        {
            [ranges addObject: [NSValue valueWithRange:foundRange]];
            
            //改变下一次的搜索范围
            searchRange.location = foundRange.location + foundRange.length;
            
            searchRange.length = self.length - searchRange.location;
            
        }
        else    //如果找不到，结束循环
            break;
        
    }
    
    
    //如果一个range都找不到，那么返回空
    if (ranges.count == 0)
        return nil;
    
    //否则把可变数组转为不可变数组，并返回
    else
        return [NSArray arrayWithArray:ranges];

}

@end






