//
//  NSDate+GetComponents.m
//  OC_9_Homework2
//
//  Created by Ibokan_Teacher on 15-4-23.
//  Copyright (c) 2015年 fghf. All rights reserved.
//

#import "NSDate+GetComponents.h"

@implementation NSDate (GetComponents)

- (NSDateComponents *)getComponentsByTimeZone:(NSTimeZone *)timeZone
{
    //需要借助一个日历类对象进行转换
    NSCalendar *calendar = [NSCalendar currentCalendar];
    
    
    //self代表就是“自己”这个NSDate对象本身
    //NSDateComponents *components = [calendar componentsInTimeZone:timeZone fromDate:self];
    
    
    //等效代码
    calendar.timeZone = timeZone;
    NSDateComponents *components = [calendar components:NSUIntegerMax fromDate:self];
    
    
    
    return components;
}

@end
