//
//  NSDate+GetComponents.h
//  OC_9_Homework2
//
//  Created by Ibokan_Teacher on 15-4-23.
//  Copyright (c) 2015年 fghf. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDate (GetComponents)

- (NSDateComponents*)getComponentsByTimeZone:(NSTimeZone*)timeZone;

@end





