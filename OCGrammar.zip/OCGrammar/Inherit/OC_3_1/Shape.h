//
//  Shape.h
//  OC_3_1
//
//  Created by Ibokan_Teacher on 15/8/19.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Shape : NSObject

//计算面积的函数
- (CGFloat)area;

@end






