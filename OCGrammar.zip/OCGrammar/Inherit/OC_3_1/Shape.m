//
//  Shape.m
//  OC_3_1
//
//  Created by Ibokan_Teacher on 15/8/19.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import "Shape.h"

@implementation Shape

- (CGFloat)area
{
    //无法计算，暂时返回0
    return 0;
}


@end











