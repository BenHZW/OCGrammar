//
//  main.m
//  OC_3_1
//
//  Created by Ibokan_Teacher on 15/8/19.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Rectangle.h"
#import "Square.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        Rectangle *r1 = [[Rectangle alloc] initWithLength:10 width:9];
        r1.length = 20;
        NSLog(@"r1: %.2f * %.2f = %.2f", r1.length, r1.width, r1.area);
        
        
        //子类重写了父类的方法，实际调用时执行的就是子类的代码
        Square *s1 = [[Square alloc] initWithLength:8 width:9];
        
        NSLog(@"s1.width: %f", s1.width);
        
        s1.length = 15;
        NSLog(@"s1.width %f", s1.width);
        
        //如果调用的是没有重写过的方法，则其效果和父类相同
        NSLog(@"s1.area: %f", s1.area);
        
        
        //调用子类特有的方法
        Square *s2 = [[Square alloc] initWithLength:4];
        
        NSLog(@"s2.length:%f, width:%f", s2.length, s2.width);
        
        
        
        
    }
    return 0;
}

