//
//  UDisk.h
//  OC-10-2
//
//  Created by Ibokan on 14-11-27.
//  Copyright (c) 2014年 fghf. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "USBDevice.h"

@interface UDisk : NSObject<USBDevice>

@end






