//
//  main.m
//  OC-10-2
//
//  Created by Ibokan on 14-11-27.
//  Copyright (c) 2014年 fghf. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "UDisk.h"
#import "Computer.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        UDisk *myUDisk = [UDisk new];
        Computer *myComputer = [Computer new];
        
        //操作电脑写数据到U盘
        [myComputer writeData:@"some data" toUSB:myUDisk atIndex:0];
        
        //操作电脑从U盘读数据
        [myComputer readAllDataFromUSB:myUDisk];
        
    }
    return 0;
}

