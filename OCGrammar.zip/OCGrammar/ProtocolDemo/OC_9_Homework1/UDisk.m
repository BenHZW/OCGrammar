//
//  UDisk.m
//  OC-10-2
//
//  Created by Ibokan on 14-11-27.
//  Copyright (c) 2014年 fghf. All rights reserved.
//

#import "UDisk.h"
#import "Computer.h"
@interface UDisk ()
{
    //这是模拟U盘数据的数组
    NSMutableArray *_data;
}
@end

@implementation UDisk

- (instancetype)init
{
    self = [super init];
    if (self)
    {
        _data = [NSMutableArray new];
    }
    return self;
}

//必须实现的协议方法
- (id)getDataAtIndex:(NSUInteger)index
{
    //如果下标越界，返回空指针
    if( index >= _data.count )
        return nil;
    //否则按照下标读取对象
    else
        return _data[index];
}


//可选协议方法
-(NSArray *)getAllData
{
    
    //把可变数组转成不可变数组，并返回
    NSArray *all = [NSArray arrayWithArray:_data];
    
    return all;
    
}


//必须实现的协议方法
-(void)putInData:(id)obj atIndex:(NSUInteger)index
{
    //防止放入空指针
    if (obj == nil)
        obj = [NSNull null];
    
    
    //如果index越界，则在数组的最后添加
    if(index >= _data.count)
        [_data addObject:obj];
    //否则按照下标取
    else
        _data[index] = obj;
}

@end





