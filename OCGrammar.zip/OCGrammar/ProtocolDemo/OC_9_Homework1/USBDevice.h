//
//  USBDevice.h
//  OC-10-2
//
//  Created by Ibokan on 14-11-27.
//  Copyright (c) 2014年 fghf. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol USBDevice <NSObject>

//从USB设备获取数据的方法
- (id)getDataAtIndex:(NSUInteger)index;

- (void)putInData:(id)obj
          atIndex:(NSUInteger)index;

@optional
- (NSArray*)getAllData;

@end


