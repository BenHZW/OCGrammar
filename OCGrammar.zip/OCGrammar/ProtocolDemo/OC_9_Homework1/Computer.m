//
//  Computer.m
//  OC-10-2
//
//  Created by Ibokan on 14-11-27.
//  Copyright (c) 2014年 fghf. All rights reserved.
//

#import "Computer.h"
#import "UDisk.h"


@interface Computer ()

//打印读取结果的方法（私有）
- (void)printObject:(id)obj;

@end


@implementation Computer
- (void)printObject:(id)obj
{
    NSLog(@"%@", obj);
}

- (void)readDataFromUSB:(id<USBDevice>)usb atIndex:(NSUInteger)index
{
    //这里要调用USB设备的读数据方法
    id obj = [usb getDataAtIndex:index];
    
    //读取之后自动打印
    [self printObject:obj];
}

- (void)readAllDataFromUSB:(id<USBDevice>)usb
{
    //将要调用usb对象的可选协议方法，先判断
    if ([usb respondsToSelector:@selector(getAllData)])
    {
        
        //这里要调用USB设备的读全部数据方法
        id obj = [usb getAllData];
        
        //读取之后自动打印
        [self printObject:obj];
        
    }
}

- (void)writeData:(id)obj toUSB:(id<USBDevice>)usb atIndex:(NSUInteger)index
{
    [usb putInData:obj atIndex:index];

}

@end





