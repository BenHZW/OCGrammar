//
//  Computer.h
//  OC-10-2
//
//  Created by Ibokan on 14-11-27.
//  Copyright (c) 2014年 fghf. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "USBDevice.h"

@interface Computer : NSObject

//参数id<USBDevice>的声明，表示只要它遵循USB设备协议就行了，具体是什么设备都不要紧

//从USB读取数据的方法
- (void)readDataFromUSB:(id<USBDevice>)usb atIndex:(NSUInteger)index;

- (void)readAllDataFromUSB:(id<USBDevice>)usb;


//写入数据到USB的方法
- (void)writeData:(id)obj
       toUSB:(id<USBDevice>)usb atIndex:(NSUInteger)index;




@end





