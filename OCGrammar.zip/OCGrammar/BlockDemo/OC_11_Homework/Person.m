//
//  Person.m
//  OC-11-Homework
//
//  Created by Ibokan_Teacher on 15-4-29.
//  Copyright (c) 2015年 fghf. All rights reserved.
//

#import "Person.h"

@implementation Person

- (void)goFrom:(NSString *)A to:(NSString *)B by:(Method)method
{
    //在这里调用代码块即可
    method(A, B);
}

@end






