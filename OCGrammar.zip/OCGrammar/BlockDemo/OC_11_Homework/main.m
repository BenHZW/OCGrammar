//
//  main.m
//  OC-11-Homework
//
//  Created by Ibokan_Teacher on 15-4-29.
//  Copyright (c) 2015年 fghf. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Person.h"
int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        Person* p1 = [Person new];
        
        [p1 goFrom:@"广州" to:@"北京" by:^(NSString *A, NSString *B) {
            //这里填写代码块具体执行的内容
            NSLog(@"从%@走到%@", A, B);
        }];
        
    }
    return 0;
}




