//
//  Person.h
//  OC-11-Homework
//
//  Created by Ibokan_Teacher on 15-4-29.
//  Copyright (c) 2015年 fghf. All rights reserved.
//

#import <Foundation/Foundation.h>

//代码块的typedef
typedef void (^Method)(NSString*, NSString*);

@interface Person : NSObject

//- (void)goFrom:(NSString*)A to:(NSString*)B by:( void(^)(NSString*, NSString*) )method;

- (void)goFrom:(NSString*)A to:(NSString*)B by:( Method )method;

@end




