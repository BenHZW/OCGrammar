//
//  main.m
//  OC_5_2
//
//  Created by Ibokan_Teacher on 15/8/21.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        //1.创建NSMutableString（可变字符串）
        //可变字符串继承于不可变字符串，所以可以使用不可变字符串的全部功能
        
        NSMutableString *mstr1 = [[NSMutableString alloc] init];
        
        NSMutableString *mstr2 = [NSMutableString stringWithFormat:@"%d", 543];
        
        //@"string"只能表示不可变字符串
        //以下方式声明可变字符串是不可行的
        //NSMutableString *mstr3 = @"gfnjrs";
        
        //替代方法
        NSMutableString *mstr4 = [NSMutableString stringWithString:@"fasgtera"];
        
        
        //2.可变字符串特有的方法，能修改自身的内容
        
        //2.1.直接更改自身内容
        [mstr1 setString:@"uhgafarej"];
        NSLog(@"mstr1: %@", mstr1);
        
        
        //2.2.拼接字符串
        [mstr1 appendString:@"_拼接"];
        NSLog(@"mstr1: %@", mstr1);
        
        [mstr1 appendFormat:@"%@, %f", mstr2, 8.2568];
        NSLog(@"mstr1: %@", mstr1);
        
        
        //2.3.字符串替换
        [mstr1 replaceCharactersInRange:NSMakeRange(3, 6) withString:@"替换内容"];
        NSLog(@"mstr1: %@", mstr1);
        
    }
    return 0;
}







