//
//  Teacher.h
//  OC_2_2
//
//  Created by Ibokan_Teacher on 15/8/17.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Teacher : NSObject

{
    @protected
    //对外不公开访问权，对内、子类公开访问权
    //如果什么都不写，默认就是@protected
    

    //建议实例变量都使用下划线开头
    NSString *_name;
    NSInteger _age;
    BOOL _isMarried;
}


//name的设置器（setter）
- (void)setName:(NSString*)name;

//name的访问器（getter）
- (NSString*)name;



//age的setter和getter
- (void)setAge:(NSInteger)age;
- (NSInteger)age;


//isMarried的setter和getter
- (void)setIsMarried:(BOOL)isMarried;
- (BOOL)isMarried;


//默认初始化函数
//因为是从父类继承过来的，所以不需要再次声明也能用
//- (id)init;



//便利初始化方法
//就是带有一些参数的init方法，在初始化同时允许传入参数用于设置初始值
- (id)initWithName:(NSString*)name
               age:(NSInteger)age
         isMarried:(BOOL)isMarried;



//便利构造器
//同时具有开辟空间和便利初始化的功能
+ (id)teacherWithName:(NSString*)name
                  age:(NSInteger)age
            isMarried:(BOOL)isMarried;



#pragma mark - 属性
//写一个property等同于声明了一个带下划线的实例变量
//并且实现了标准的setter和getter
@property(nonatomic)BOOL isMale;


@end









