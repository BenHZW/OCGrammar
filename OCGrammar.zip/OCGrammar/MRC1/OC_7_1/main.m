//
//  main.m
//  OC_7_1
//
//  Created by Ibokan_Teacher on 15/8/26.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "Student.h"
#import "Teacher.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        //1.使得引用计数器变为1的情况
        
        //1.1.alloc创建对象
        NSMutableArray *marr1 = [[NSMutableArray alloc] init];
        NSLog(@"marr1.retainCount:%lu", marr1.retainCount);
        
        //1.2.new也可以
        
        
        //2.使引用计数器加1：retain
        NSMutableArray *marr2 = [marr1 retain];
        NSLog(@"marr2.retainCount:%lu", marr2.retainCount);
        
        
        //3.让引用计数器马上减1：release
        [marr1 release];
        //安全起见，可将该指针置空
        marr1 = nil;
        
        NSLog(@"marr2.retainCount:%lu", marr2.retainCount);
        
        
        //当对象的引用计数器变为0时，其空间就会被系统回收
        [marr2 release];
        //此后该数组已经被销毁回收，不可再用
        marr2 = nil;
        
        
        
        //4.综合例子
        Student *stu1 = [[Student alloc] initWithName:@"CZF" age:30 number:@1];
        
        Student *stu2 = [Student new];
        stu2.name = @"PET";
        stu2.age = 10;
        stu2.number = @2;
        
        NSLog(@"stu1.retainCount:%lu", stu1.retainCount);
        NSLog(@"stu2.retainCount:%lu", stu2.retainCount);
        
        
        //把两个Student放入数组
        NSMutableArray *marr3 = [NSMutableArray new];
        [marr3 addObject:stu1];
        [marr3 addObject:stu2];
        
        NSLog(@"stu1,stu2放入数组后");
        NSLog(@"stu1.retainCount:%lu", stu1.retainCount);
        NSLog(@"stu2.retainCount:%lu", stu2.retainCount);
        
        
        //从容器中提取对象
        Student *stu3 = [marr3[0] retain];
        NSLog(@"stu3.retainCount:%lu", stu3.retainCount);
        
        [stu3 release];
        
        
        //如果从容器中移除对象
        [marr3 removeObjectAtIndex:1];
        NSLog(@"从容器中移除对象");
        NSLog(@"stu2.retainCount:%lu", stu2.retainCount);
        
        
        //销毁容器
        [marr3 release];
        marr3 = nil;
        
        NSLog(@"容器销毁后");
        NSLog(@"stu1.retainCount:%lu", stu1.retainCount);
        
        //见识一下dealloc
        //注意：dealloc是在对象销毁前自动调用的
        [stu1 release];
        [stu2 release];
        
        
        //用便利构造器创建对象
        Student *stu4 = [Student studentWithName:@"Dai" age:52 number:@4];
        NSLog(@"stu4.retainCount:%lu", stu4.retainCount);
        
        
        
        //5.在MRC项目中使用ARC写的类
        //需要给用ARC写的m文件标记上
        //-fobjc-arc
        //这样被标记的m文件内部就以ARC的方式工作
        Teacher *t1 = [[Teacher alloc] initWithName:@"CJJ" age:18 isMarried:NO];
        
        //在本文件MRC的环境下，按照该环境的特性进行内存管理
        [t1 release];
        
        
        
    }
    //当程序运行到自动释放结束的地方，池内部执行过autorelease的对象就会引用计数器减1
    
    return 0;
}





