//
//  Student.m
//  OC_7_1
//
//  Created by Ibokan_Teacher on 15/8/26.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import "Student.h"

@implementation Student

@synthesize name = _name;

//当property使用了内存管理关键字后，即使不重写setter亦可
#warning 如果因为某种需要重写了带有内存管理的setter，就要注意写上应有的内存管理步骤
/*
- (void)setName:(NSString *)name
{
    //1.拷贝传进来的字符串
    NSString *newName = [name copy];
    
    //2.放弃对原实例变量的拥有权
    //计数器减1
    [_name release];
    
    //3.实例变量指向新的对象
    _name = newName;
}

- (NSString *)name
{
    //getter一般不做内存管理
    return _name;
}
*/


- (void)setAge:(NSInteger)age
{
    //基本数据类型不用做内存管理
    _age = age;
}

- (NSInteger)age
{
    return _age;
}

- (void)setNumber:(NSNumber *)number
{
    //1.将传进来的对象引用计数器加1
    [number retain];
    
    //2.原实例变量的引用计数器减1
    [_number release];
    
    //3.实例变量获得新的引用
    _number = number;
}

- (NSNumber *)number
{
    return _number;
}


- (id)initWithName:(NSString *)name age:(NSInteger)age number:(NSNumber *)number
{
    if (self = [super init])
    {
        _name = [name copy];
        _age = age;
        _number = [number retain];
    }
    return self;
}


+ (id)studentWithName:(NSString *)name age:(NSInteger)age number:(NSNumber *)number
{
    Student *stu = [[self alloc] initWithName:name age:age number:number];
    
    //autorelease表示延后释放，当这个对象碰到自动释放池的结尾才会让引用计数器减1
    return [stu autorelease];
    
    
    //return stu;
}



#pragma mark - 在对象即将被销毁之前调用的方法

- (void)dealloc
{
    NSLog(@"Student %@ dealloc", _name);
    //1.释放资源，收拾手尾
    [_name release];
    [_number release];
    
    //2.调用父类方法
    //在ARC环境下无法调用
    [super dealloc];
}


@end







