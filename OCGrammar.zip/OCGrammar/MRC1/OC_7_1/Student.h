//
//  Student.h
//  OC_7_1
//
//  Created by Ibokan_Teacher on 15/8/26.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Student : NSObject

{
    //NSString *_name;
    NSInteger _age;
    NSNumber *_number;
}

//name的setter、getter
/*
- (void)setName:(NSString*)name;
- (NSString*)name;
*/
//在property中使用内存管理
//会自动生成带有内存管理步骤的setter
@property(nonatomic,copy)NSString *name;


//age的setter、getter
- (void)setAge:(NSInteger)age;
- (NSInteger)age;

//基本数据类型的property内存管理关键字，一般用assign，或者不写
@property(nonatomic/*, assign*/)NSInteger age;


//number的setter、getter
- (void)setNumber:(NSNumber*)number;
- (NSNumber*)number;

@property(nonatomic, retain)NSNumber *number;




//便利初始化方法
- (id)initWithName:(NSString*)name
               age:(NSInteger)age
            number:(NSNumber*)number;


//便利构造器
+ (id)studentWithName:(NSString*)name
                  age:(NSInteger)age
               number:(NSNumber*)number;


@end






