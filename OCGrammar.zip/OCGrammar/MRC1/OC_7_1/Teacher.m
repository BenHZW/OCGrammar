//
//  Teacher.m
//  OC_2_2
//
//  Created by Ibokan_Teacher on 15/8/17.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import "Teacher.h"

@implementation Teacher

#pragma mark - 三对setter和getter

- (void)setName:(NSString *)name
{
    _name = name;
}

- (NSString *)name
{
    return _name;
}


- (void)setAge:(NSInteger)age
{
    //如有需要可以再setter中加入一定的逻辑，使得实例变量的赋值合理化
    if (age >= 18)
    {
        _age = age;
    }
    else
    {
        _age = 18;
    }
}
- (NSInteger)age
{
    return _age;
}


- (void)setIsMarried:(BOOL)isMarried
{
    _isMarried = isMarried;
}


- (BOOL)isMarried
{
    return _isMarried;
}


#pragma mark - 重写默认初始化方法
- (id)init
{
    //1.执行父类的初始化方法
    self = [super init];
    
    //2.如果初始化成功，self指针应不为空，这时再初始化本对象
    if (self != nil)
    {
        //初始化本对象
        _name = @"No name";
        _age = 18;
        _isMarried = NO;
    }
    
    //3.返回自身
    return self;
}


#pragma mark - 便利初始化方法
- (id)initWithName:(NSString *)name age:(NSInteger)age isMarried:(BOOL)isMarried
{
    self = [super init];
    
    if (self != nil)
    {
        //初始化使用的是传进来的参数，而不是默认值
        _name = name;
        
        if (age >= 18)
        {
            _age = age;
        }
        else
        {
            _age = 18;
        }
        
        _isMarried = isMarried;
        
    }
    
    return self;
}


#pragma mark - 便利构造器
+ (id)teacherWithName:(NSString *)name age:(NSInteger)age isMarried:(BOOL)isMarried
{
    //已有的便利初始化方法可以直接利用，顺便结合alloc方法的调用，创建对象
    Teacher *t = [[self alloc] initWithName:name age:age isMarried:isMarried];
    
    //返回这个对象
    return t;
}


@end







