//
//  Rectangle.m
//  OC_2_3
//
//  Created by Ibokan_Teacher on 15/8/18.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import "Rectangle.h"

@implementation Rectangle

#pragma mark - 重写长和宽的setter
- (void)setLength:(double)length
{
    //“属性”已经包含了一个带有下划线的实例变量
    if (length < 0)
    {
        _length = 0;
    }
    else
    {
        _length = length;
    }
}


- (void)setWidth:(double)width
{
    if (width < 0)
    {
        _width = 0;
    }
    else
    {
        _width = width;
    }
}


#pragma mark - 计算面积的方法

//当使用了@property area之后
//下面就相当于重写了area的getter
- (double)area
{
    return self.length * self.width;
}


@end






