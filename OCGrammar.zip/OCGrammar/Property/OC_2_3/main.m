//
//  main.m
//  OC_2_3
//
//  Created by Ibokan_Teacher on 15/8/18.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Rectangle.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        Rectangle *r1 = [Rectangle new];
        r1.length = 10.2;
        r1.width = 5.1;
        NSLog(@"r1{ length:%f, width:%f }", r1.length, r1.width);
        
        NSLog(@"r1 area: %f", [r1 area]);
        
        //因为area方法符合标准getter命名规范，所以也能使用点语法调用
        NSLog(@"r1 area: %f", r1.area);
        
        
    }
    return 0;
}





