//
//  Rectangle.h
//  OC_2_3
//
//  Created by Ibokan_Teacher on 15/8/18.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Rectangle : NSObject

//两个属性：长和宽
//property自动生成的setter只会做简单的赋值操作
//如果要加入自定义逻辑，还必须重写setter
@property(nonatomic)double length;
@property(nonatomic)double width;


//计算面积的方法
//- (double)area;


//只读属性
//意味着没有setter
@property(nonatomic, readonly)double area;



@end









