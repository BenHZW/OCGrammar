//
//  Button.m
//  OC-12-Homework2
//
//  Created by Ibokan on 14-12-3.
//  Copyright (c) 2014年 fghf. All rights reserved.
//

#import "Button.h"

@interface Button ()

//弹起的方法，这个方法是在收到通知的时候自动调用的
//可以不在延展声明私有方法，而是直接实现
- (void)pop:(NSNotification *)nf;

@end


@implementation Button

- (id)initWithNumber:(NSUInteger)number
{
    self = [super init];
    if (self)
    {
        _number = number;
        
        //注册观察者
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(pop:) name:@"pop" object:nil];
        //nil表示不指定某个对象发过来的通知，也就是观察所有对象发出的通知
    }
    return self;
}

- (void)push
{
    NSLog(@"按钮%lu √", self.number);
    
    //按钮被按下后，要发通知，通知其他按钮弹起
    [[NSNotificationCenter defaultCenter] postNotificationName:@"pop" object:self];
    
    //object里面填写发送者，以便识别
}

- (void)pop:(NSNotification *)nf
{
    //获取通知的发送者是谁
    id obj = nf.object;
    
    //如果通知是自己发出来的，那么就不用弹起了
    //反之，如果通知的发送者不是自己，才要弹起来
    if (obj != self)
    {
        NSLog(@"按钮%lu ×", self.number);
    }
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"pop" object:nil];
}

@end




