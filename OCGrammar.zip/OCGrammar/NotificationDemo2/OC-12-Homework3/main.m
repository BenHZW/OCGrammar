//
//  main.m
//  OC-12-Homework2
//
//  Created by Ibokan on 14-12-3.
//  Copyright (c) 2014年 fghf. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Button.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        Button *b0 = [[Button alloc]initWithNumber:0];
        Button *b1 = [[Button alloc]initWithNumber:1];
        Button *b2 = [[Button alloc]initWithNumber:2];
        Button *b3 = [[Button alloc] initWithNumber:3];
        Button *b4 = [[Button alloc]initWithNumber:4];
        
        [b1 push];
        
        NSLog(@"-------------");
        
        [b2 push];
        
        NSLog(@"-------------");
        
        [b0 push];
        
        NSLog(@"-------------");
        
        [b4 push];
        
        
    }
    return 0;
}

