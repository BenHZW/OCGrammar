//
//  Button.h
//  OC-12-Homework2
//
//  Created by Ibokan on 14-12-3.
//  Copyright (c) 2014年 fghf. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Button : NSObject

//按下的方法
- (void)push;

//按钮的编号
@property(nonatomic)NSUInteger number;

//便利初始化方法
- (id)initWithNumber:(NSUInteger)number;

@end






