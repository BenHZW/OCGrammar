//
//  main.m
//  OC_11_2
//
//  Created by Ibokan_Teacher on 15/9/2.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        //一.MRC下block的内存管理
#if !__has_feature(objc_arc)
        
        //1.代码块对代码块以外的对象的引用的影响
        NSMutableString *mstr1 = [NSMutableString new];
        NSLog(@"mstr1.retainCount: %lu", mstr1.retainCount);
        
        void (^block1)() = ^()
        {
            //声明一个代码块实体使用了代码块外的对象，则代码块会对这些对象有弱引用
            NSLog(@"block mstr1.retainCount: %lu", mstr1.retainCount);
        };
        block1();
        
        
        
        //copy代码块，会对代码块中使用的代码块外的对象发生强引用
        void (^block1Cpy)() = [block1 copy];
        block1Cpy();
        
        //遵循一般的内存管理原则，需要对copy的代码块release
        [block1Cpy release];
        
        //copy的代码块释放后，也会自动解除对对象的强引用
        
        block1();
        
        
        [mstr1 release];
        
        
        //2.如果想copy代码块时不对代码块外的对象发生强引用
        __block NSMutableString *mstr2 = [NSMutableString new];
        
        NSMutableString *mstr3 = [NSMutableString new];
        __block NSMutableString *mstr3Weak = mstr3;
        
        
        void (^block2)() = ^()
        {
            NSLog(@"block mstr2.retainCount: %lu", mstr2.retainCount);
            
            NSLog(@"block mstr3Weak.retainCount: %lu", mstr3Weak.retainCount);
        };
        block2();
        
        //用__block声明的对象不会被代码块强引用
        void (^block2Cpy)() = [block2 copy];
        block2Cpy();
        
        
        [block2Cpy release];
        [mstr2 release];
        [mstr3 release];       
        
        
#else   //二.ARC下的内存管理

        //1.ARC下，不管有没有copy，代码块都会对使用到的代码块外对象进行强引用
        //注意：__block也表示强引用
        NSMutableString *mstr4 = [NSMutableString new];
        
        void (^block3)() = ^()
        {
            NSLog(@"block mstr4.retainCount: %lu", CFGetRetainCount((__bridge CFTypeRef)(mstr4)) );
        };
        block3();
        
        
        //2.如果不想代码块强引用代码块外的对象
        //与MRC的处理方法不同，这里要使用__weak或__unsafe_unretain处理
        __weak NSMutableString *mstr4Weak = mstr4;
        void (^block4)() = ^()
        {
            NSLog(@"block mstr4Weak.retainCount: %lu", CFGetRetainCount((__bridge CFTypeRef)(mstr4Weak)) );
        };
        block4();
        
        
        
#endif
        
    }
    return 0;
}





