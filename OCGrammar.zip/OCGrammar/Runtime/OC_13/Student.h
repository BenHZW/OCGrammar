//
//  Student.h
//  OC_13
//
//  Created by Ibokan_Teacher on 15/9/7.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Student : NSObject

@property(nonatomic)NSInteger age;

@property(nonatomic)CGFloat height;

@property(nonatomic, copy)NSString *name;

- (void)study;

- (void)run:(NSInteger)km;

@end





