//
//  main.m
//  OC_13
//
//  Created by Ibokan_Teacher on 15/9/7.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Student.h"

//运行时相关的头文件
#import <objc/runtime.h>


//定义一个C语言函数，后面用于动态添加到类中作为实例方法
//第1个参数必然是id
//第2个参数必然是SEL
//后面的参数根据实际情况而定
//例如，此函数将作为Student类的实例方法
//-(void)sleep:(NSUInteger)hour;
void sleepFunction(id student, SEL sleepSel, NSUInteger hour)
{
    Student *stu = student;
    NSLog(@"%@睡觉%ld小时", stu.name, hour);
}




int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        Student *stu1 = [Student new];
        stu1.name = @"Roger";
        stu1.age = 30;
        stu1.height = 1.5;
        
        
        //1.给对象动态增加属性
        //增加的属性仅属于该对象，且仅在运行时有效
        
        //参数：
        //①为哪个对象添加属性
        //②动态属性的名字，用C语言字符串表示
        //③动态属性的值，必须是对象
        //④动态属性的内存管理策略
        
        //设置/添加动态属性
        objc_setAssociatedObject(stu1, "weight", @100, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        
        
        //访问动态属性
        NSNumber *weight =  objc_getAssociatedObject(stu1, "weight");
        NSLog(@"weight: %@", weight);
        
        
        //移除所有动态属性
        objc_removeAssociatedObjects(stu1);
        
        
        //2.动态执行方法
        
        //2.1.SEL（selector）类型，用于表示方法名
        
        //获取selector
        //注意：获取selector时，如果该方法有参数，那么:不能漏
        SEL studySel = @selector(study);
        SEL runSel = NSSelectorFromString(@"run:");
        
        
        //2.2.用performSelector方法执行selector
        if ([stu1 respondsToSelector:studySel])
        {
            //withObject允许填入一个参数，这个参数必须是对象，如果没有参数则填入nil
            //afterDelay填入延后多少秒执行
            
            //[stu1 performSelector:studySel withObject:nil afterDelay:0];
            
            [stu1 performSelector:studySel withObject:nil withObject:nil];
        }
        
        
        //2.3.获取IMP执行方法
        IMP runIMP = [stu1 methodForSelector:runSel];
        
        //IMP的参数
        //①一定是执行该方法的对象
        //②一定是表示该方法的selector
        //其余参数为该方法本身的参数，依次填入
        
#if __has_feature(objc_arc)
        //ARC下为防止出错，要先把IMP转换成普通函数指针
        //返回值、参数根据具体的IMP和selector而定
        void (*runFunction)(id, SEL, NSInteger) = (void(*))runIMP;
        
        //调用函数指针
        runFunction(stu1, runSel, 5);
        
#else
        //MRC下可以直接调用IMP
        runIMP(stu1, runSel, 5);
#endif
        
        
        //3.动态获取一个类的所有属性
        
        //需要一个整数变量记录属性的个数
        unsigned propertyCount;
        
        //class_copyPropertyList函数
        //参数①：要获取属性的类
        //参数②：记录数组元素个数的整数的指针
        //返回值：一个动态分配的C语言数组
        objc_property_t *propertyArray = class_copyPropertyList([Student class], &propertyCount);
        
        NSLog(@"%@类的属性：", [Student class]);
        
        //用下标访问数组元素
        for (int i = 0; i < propertyCount; ++i)
        {
            //取出一个元素
            objc_property_t aProperty = propertyArray[i];
            
            
            //获取属性的名字，返回的是一个C语言字符串
            const char *aPropertyName = property_getName(aProperty);
            
            //将C语言字符串转成NSString
            NSString *aPropertyNameString = @(aPropertyName);
            
            
            //使用KVC访问这个属性
            NSLog(@"stu1.%@: %@", aPropertyNameString, [stu1 valueForKey:aPropertyNameString]);
        }
        
        //propertyArray是C语言动态分配的空间，ARC对此无效，必须手动释放
        free(propertyArray);
        
        
        //4.动态获取类的实例方法列表
        
        //记录列表中有多少个方法的变量
        unsigned methodCount;
        
        //class_copyMethodList函数
        //参数①：要获取实例方法的类
        //参数②：记录数组元素个数的整数的指针
        //返回值：一个动态分配的C语言数组
        Method *methodArray = class_copyMethodList([Student class], &methodCount);
        
        NSLog(@"%@类的实例方法-----", [Student class]);
        
        for (int i = 0; i < methodCount; ++i)
        {
            //取出数组中的某个元素（每个元素是一个方法）
            Method aMethod = methodArray[i];
            
            //获得这个方法对应的selector
            SEL aSel = method_getName(aMethod);
            
            //将selector转换成C语言字符串以便打印
            const char *aSelName = sel_getName(aSel);
            
            NSLog(@"%s", aSelName);
        }
        
        //动态分配的C语言数组要手动释放
        free(methodArray);
        
        
        
        
        
        
        //5.动态为类添加实例方法
        NSLog(@"动态为%@类添加实例方法", [Student class]);
        
        //此处将要把sleepFunction添加作为Student类的实例方法
        
        //先要获得一个表示新添加的实例方法对应的IMP的形式化表达的C语言字符串
        char sleepIMPTypeString[10];
        
        //这个字符串由函数的返回值、参数所对应类型代码连接而成
        //类型代码通过@encode(类型)获得
        //与sleepFunction的返回值、参数依次对应\
        void是返回值，id是第1个参数，SEL是第2个参数，NSUInteger是第3个参数
        sprintf(sleepIMPTypeString, "%s%s%s%s", @encode(void), @encode(id), @encode(SEL), @encode(NSUInteger));
        
        //留意打印结果
        NSLog(@"IMPTypeString: %s", sleepIMPTypeString);
        
        
        //class_addMethod函数
        //参数①：要添加实例方法的类
        //参数②：实例方法对应的selector，名字自定，如果有参数要加上:
        //参数③：这个方法对应的IMP，由一个C语言函数指针转换而成即可
        //参数④：表示IMP形式化的C语言字符串
        class_addMethod([Student class], @selector(sleep:), (IMP)sleepFunction, sleepIMPTypeString);
        
        //MRC下可以这样强制调用动态添加的方法
        //[stu1 sleep:10];
        
        //6.动态替换类的实例方法
        //class_replaceMethod函数的作用：将已存在的实例方法的IMP替换为另一个IMP，从而改变实例方法的实现
        //参数：与class_addMethod函数的参数意义相同
        
        
        //请自行尝试将run:方法的实现替换为sleepFunction
        //class_replaceMethod(<#__unsafe_unretained Class cls#>, <#SEL name#>, <#IMP imp#>, <#const char *types#>)
        
        //替换完之后再调用run:方法测试效果

        
        
    }
    return 0;
}






