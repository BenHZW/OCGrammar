//
//  Student.m
//  OC_13
//
//  Created by Ibokan_Teacher on 15/9/7.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import "Student.h"

@implementation Student

- (void)study
{
    NSLog(@"好好学习");
}

- (void)run:(NSInteger)km
{
    NSLog(@"跑%ld千米", km);
}


@end









