//
//  main.m
//  OC_8
//
//  Created by Ibokan_Teacher on 15/8/28.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        //1.日期类
        
        //以系统当前时间创建日期
        NSDate *date1 = [NSDate new];
        NSLog(@"date1:%@", date1);
        
        NSDate *date2 = [NSDate date];
        NSLog(@"date2:%@", date2);
        
        
        //以当前时间为基准偏移一定秒数创建时间
        NSDate *date3 = [NSDate dateWithTimeIntervalSinceNow:60];
        NSLog(@"date3:%@",date3);
        
        
        
        //比较两个日期
        NSComparisonResult date2CmpDate3 = [date2 compare:date3];
        NSLog(@"date2CmpDate3: %ld", date2CmpDate3);
        
        
        //2.时区类
        
        //查看一些已知的时区名字
        NSArray *timeZoneNames =  [NSTimeZone knownTimeZoneNames];
        NSLog(@"timeZoneNames: %@", timeZoneNames);
        
        
        //根据时区名字创建时区
        NSTimeZone *hkZone = [NSTimeZone timeZoneWithName:@"Asia/Hong_Kong"];
        NSLog(@"hkZone: %@", hkZone);
        
        //更多的时区在
        //路径/usr/share/zoneinfo
        
        NSTimeZone *PRCZone = [NSTimeZone timeZoneWithName:@"PRC"];
        NSLog(@"PRCZone:%@", PRCZone);
        
        
        //获得本地时区
        NSTimeZone *localTimeZone = [NSTimeZone localTimeZone];
        NSLog(@"localTimeZone:%@", localTimeZone);
        
        
        //3.日历类（历法类）
        NSCalendar *currentCalendar = [NSCalendar currentCalendar];
        //下面会用到
        
        
        //4.日期元素类
        
        //4.1.自定义日期元素
        NSDateComponents *components1 = [NSDateComponents new];
        //设置各种时间元素值
        components1.hour = 18;
        components1.minute = 1;
        components1.second = 12;
        components1.year = 2016;
        components1.month = 2;
        components1.day = 1;
        components1.timeZone = PRCZone;
        
        //借助日历对象将日期元素转成日期对象
        NSDate *date4 = [currentCalendar dateFromComponents:components1];
        NSLog(@"date4:%@", date4);
        
        
        
        //4.2.把NSDate借助日历对象转换成日期内容
        //第一个参数填入要提取那些单位的选项
        NSDateComponents *components2 = [currentCalendar components:NSCalendarUnitHour | NSCalendarUnitMinute | NSCalendarUnitSecond fromDate:date1];
        
        NSLog(@"components2.hour:%ld", components2.hour);
        
        
        //5.日期格式化类
        NSDateFormatter *formater1 = [NSDateFormatter new];
        
        //设置格式化时区
        formater1.timeZone = PRCZone;
        
        
        //设置日期字符串格式
        formater1.dateFormat = @"yyyy-MM-dd HH:mm:ss";
        
        
        //把日期转换成字符串
        NSString *dateString1 = [formater1 stringFromDate:date1];
        NSLog(@"dateString1: %@", dateString1);
        
        
        //把日期字符串转换成日期对象
        //这个字符串要严格遵守前面制定的格式
        NSDate *date5 = [formater1 dateFromString:@"2017-03-09 18:12:30"];
        NSLog(@"date5: %@", date5);
        
        
    }
    return 0;
}






