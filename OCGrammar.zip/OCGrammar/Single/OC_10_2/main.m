//
//  main.m
//  OC_10_2
//
//  Created by Ibokan_Teacher on 15/9/1.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Sun.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        Sun *sun1 = [Sun getInstance];
        Sun *sun2 = [[Sun alloc] init];
        Sun *sun3 = [Sun new];
        
        NSLog(@"sun1: %@", sun1);
        NSLog(@"sun2: %@", sun2);
        NSLog(@"sun3: %@", sun3);
        
        
    }
    return 0;
}





