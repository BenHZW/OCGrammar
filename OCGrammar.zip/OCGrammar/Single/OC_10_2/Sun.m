//
//  Sun.m
//  OC_10_2
//
//  Created by Ibokan_Teacher on 15/9/1.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import "Sun.h"

//声明一个全局对象，这就是本类的唯一对象
static Sun *sun = nil;

@implementation Sun

//在implementation也可以声明实例变量
{
    //默认是private
    BOOL _isInitialized;//标记是否初始化过的变量
}

#pragma mark - 在getInstance方法中创建对象
+ (instancetype)getInstance
{
    //@synchronized(self)的作用是对本类加锁，防止多条线程同时进入if判断，进而防止同时alloc
    @synchronized(self)
    {
        //判断唯一对象是否已经存在
        if (sun == nil)
        {
            //不存在时才创建
            sun = [[self alloc] init];
        }
    }
        
    //返回这个唯一对象
    return sun;
}


#pragma mark - 可选：重写allocWithZone
//重写之后，连alloc、new都无法创建多个对象
+ (id)allocWithZone:(struct _NSZone *)zone
{
    @synchronized(self)
    {
        if (sun == nil)
        {
            sun = [super allocWithZone:zone];
        }
    }
    
    return sun;
}

#pragma mark - 如果要封闭alloc，可以考虑连带封闭init
- (instancetype)init
{
    //对本对象加锁
    @synchronized(self)
    {
        //如果没有初始化过，才去初始化
        if (_isInitialized == NO)
        {
            self = [super init];
            if (self)
            {
                _isInitialized = YES;
                
                //初始化其他变量...
            }
        }
    }
    
    return self;
}


#pragma mark - 在MRC环境下才需要重写的方法

#if !__has_feature(objc_arc)
- (id)retain
{
    //直接返回自身，去掉引用计数器+1的功能
    return self;
}

- (NSUInteger)retainCount
{
    //直接返回一个很大的数
    return NSUIntegerMax;
}


- (oneway void)release
{
    //什么都不用做，去除了引用计数器-1的功能
}

- (id)autorelease
{
    //取出引用计数器-1的功能
    //但是要返回自身
    return self;
}
#endif


#pragma mark - 跟单例设计没有关系的普通方法

- (void)shine
{
    NSLog(@"太阳亮瞎你的狗眼");
}


@end








