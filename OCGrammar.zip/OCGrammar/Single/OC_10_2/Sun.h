//
//  Sun.h
//  OC_10_2
//
//  Created by Ibokan_Teacher on 15/9/1.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Sun : NSObject

//单例类一般都要有一个专门返回这个类的唯一对象的方法
+ (instancetype)getInstance;


//其他方法与普通的类无异
- (void)shine;

@end






