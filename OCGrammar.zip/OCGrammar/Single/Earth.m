//
//  Earth.m
//  OC_10_2
//
//  Created by Ibokan_Teacher on 15/9/1.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import "Earth.h"

static Earth *earth = nil;

@implementation Earth

//除了可以在getInstance时创建对象，还可以：
+ (void)initialize
{
    @synchronized(self)
    {
        if (earth == nil)
            earth = [[self alloc] init];
    }
}



+ (instancetype)getInstance
{
    return earth;
}


@end







