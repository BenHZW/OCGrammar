//
//  StockSever.m
//  OC_12_2
//
//  Created by Ibokan_Teacher on 15/9/6.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import "StockServer.h"

@interface StockServer ()

//在延展里写一个相同的属性，但不写readonly
//这样就有了一个私有的setter
@property(nonatomic)NSInteger stockData;


@end


@implementation StockServer

- (void)stockDataRandomlyChange
{
    NSInteger randomData = (NSInteger)(arc4random() % 21) - 10;
    
    //直接改变实例变量，并不会触发KVO
    //_stockData = randomData;
    
    //要触发KVO，可以使用：
    
    //1.标准的setter
    //self.stockData = randomData;
    
    //2.KVC
    [self setValue:@(randomData) forKeyPath:@"stockData"];
    
}

@end







