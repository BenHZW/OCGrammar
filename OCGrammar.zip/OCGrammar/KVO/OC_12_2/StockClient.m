//
//  StockClient.m
//  OC_12_2
//
//  Created by Ibokan_Teacher on 15/9/6.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import "StockClient.h"
#import "StockServer.h"

@implementation StockClient

- (instancetype)initWithServer:(StockServer *)server
{
    self = [super init];
    if (self)
    {
        //设置服务器
        _server = server;
        
        //对服务器添加自身为观察者
        [server addObserver:self forKeyPath:@"stockData" options:NSKeyValueObservingOptionOld | NSKeyValueObservingOptionNew context:nil];
    }
    return self;
}


//被观察者的setter需要重写
- (void)setServer:(StockServer *)server
{
    //1.对旧的server移除观察者
    [_server removeObserver:self forKeyPath:@"stockData"];
    
    //2.赋值新的服务器
    _server = server;
    
    //3.对新的server添加观察者
    [server addObserver:self forKeyPath:@"stockData" options:NSKeyValueObservingOptionOld | NSKeyValueObservingOptionNew context:nil];
    
}


- (void)dealloc
{
    //对服务器移除观察者
    [_server removeObserver:self forKeyPath:@"stockData"];
}


#pragma mark - 监听被观察者回调的方法
//当被观察者的对应键值发生变化时会自动调用

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
    //if分支，判断不同的监听键值，从而做出反应
    if ([keyPath isEqualToString:@"stockData"])
    {
        //执行该分支的对应操作
        
        //在change字典里取出需要的数据
        NSNumber *newValue = change[NSKeyValueChangeNewKey];
        NSNumber *oldValue = change[NSKeyValueChangeOldKey];
        
        NSLog(@"%@ ---> %@", oldValue, newValue);
        
    }
    //最后的else分支，将上述没有出现的键值交给父类监听
    //或者，如果父类是NSObject，则什么都不用做
    else
    {
        //[super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
    }
}



@end







