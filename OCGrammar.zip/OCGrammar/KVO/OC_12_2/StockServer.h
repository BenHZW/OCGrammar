//
//  StockSever.h
//  OC_12_2
//
//  Created by Ibokan_Teacher on 15/9/6.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface StockServer : NSObject

//股票数据
@property(nonatomic, readonly)NSInteger stockData;

//让股票数据随机变化的方法
- (void)stockDataRandomlyChange;

@end





