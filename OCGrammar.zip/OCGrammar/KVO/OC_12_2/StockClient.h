//
//  StockClient.h
//  OC_12_2
//
//  Created by Ibokan_Teacher on 15/9/6.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>

@class StockServer;

@interface StockClient : NSObject

//用一个属性记录要观察的服务器
@property(nonatomic, weak)StockServer *server;

//便利初始化方法
- (instancetype)initWithServer:(StockServer*)server;

@end






