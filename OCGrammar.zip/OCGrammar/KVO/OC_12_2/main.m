//
//  main.m
//  OC_12_2
//
//  Created by Ibokan_Teacher on 15/9/6.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "StockServer.h"
#import "StockClient.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        StockServer *server1 = [StockServer new];
        
        StockClient *client1 = [[StockClient alloc] initWithServer:server1];
        
        
        //服务器数据随机变10次
        for (int i = 0; i < 10; ++i)
        {
            [server1 stockDataRandomlyChange];
        }
        
        
    }
    return 0;
}

