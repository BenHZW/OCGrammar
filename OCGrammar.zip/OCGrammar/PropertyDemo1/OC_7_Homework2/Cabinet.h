//
//  Cabinet.h
//  OC_7_Homework2
//
//  Created by Ibokan_Teacher on 15/8/28.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>

//用宏定义写下三个key
#define BELOW_30 @"<30"
#define BETWEEN_30_80 @"30-80"
#define ABOVE_80 @">80"

@class Box;

@interface Cabinet : NSObject
{
    //用不可变字典管理三个格子
    NSDictionary *_lattices;
}


//放入盒子的方法，需要提供一个年份的key
- (void)putInBox:(Box*)box
      forYearKey:(NSString*)yearKey;


//根据key获取某个格子里面的所有盒子
- (NSArray*)boxesForYearKey:(NSString*)yearKey;


//移除某个盒子的方法，并返回这个盒子
- (Box*)removeBoxAtIndex:(NSUInteger)index forYearKey:(NSString*)yearKey;


//对某个年份的全部盒子进行条件排序
- (void)sortBoxesForYearKey:(NSString*)yearKey;


@end








