//
//  Wine.m
//  OC_7_Homework2
//
//  Created by Ibokan_Teacher on 15/8/28.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import "Wine.h"

@implementation Wine

#pragma mark - 便利初始化方法
- (id)initWithName:(NSString *)name year:(NSInteger)year
{
    if (self = [super init])
    {
        //name根据设计，需要copy
        _name = [name copy];
        
        _year = year;
    }
    return self;
}

#pragma mark - compare比较方法
- (NSComparisonResult)compare:(Wine *)anotherWine
{
    //直接返回两瓶酒的年份差
    return self.year - anotherWine.year;
}


#pragma mark - 重写description
- (NSString *)description
{
    return [NSString stringWithFormat:@"%@ %ld years", self.name, self.year];
}

#pragma mark - 析构方法
- (void)dealloc
{
    [_name release];
    
    [super dealloc];
}



@end









