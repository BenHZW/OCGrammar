//
//  Cabinet.m
//  OC_7_Homework2
//
//  Created by Ibokan_Teacher on 15/8/28.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import "Cabinet.h"
#import "Box.h"

@implementation Cabinet

#pragma mark - 重写默认初始化方法
- (id)init
{
    if (self = [super init])
    {
        //生成存储结构
        
        //1.三个可变数组
        NSMutableArray *lattices1 = [NSMutableArray new];
        NSMutableArray *lattices2 = [NSMutableArray new];
        NSMutableArray *lattices3 = [NSMutableArray new];
        
        
        //2.构建字典
        _lattices = [@{BELOW_30: lattices1, BETWEEN_30_80: lattices2, ABOVE_80: lattices3} retain];
        
        //3.释放三个可变数组
        [lattices1 release];
        [lattices2 release];
        [lattices3 release];
        
    }
    
    return self;
}

#pragma mark - 放入盒子
- (void)putInBox:(Box *)box forYearKey:(NSString *)yearKey
{
    //判断指针是否为空
    if (box == nil)
    {
        return;
    }
    
    //根据key取出对应的可变数组
    NSMutableArray *theLatties = _lattices[yearKey];
    
    //把box放入数组
    [theLatties addObject:box];
    
}


#pragma mark - 获取某个格子全部盒子
- (NSArray *)boxesForYearKey:(NSString *)yearKey
{
    //取出对应的可变数组
    NSMutableArray *theLattice = _lattices[yearKey];
    
    //转换成不可变数组并返回
    return [NSArray arrayWithArray:theLattice];
}


#pragma mark - 移除盒子的方法
- (Box *)removeBoxAtIndex:(NSUInteger)index forYearKey:(NSString *)yearKey
{
    //取得对应的可变数组
    NSMutableArray *theLattice = _lattices[yearKey];
    
    //取得对应下标的box，需要持有它
    Box *theBox = [theLattice[index] retain];
    
    //从数组中移除盒子
    [theLattice removeObjectAtIndex:index];
    
    return [theBox autorelease];
}

#pragma mark - 排序
- (void)sortBoxesForYearKey:(NSString *)yearKey
{
    //取出需要排序的可变数组
    NSMutableArray *theLattice = _lattices[yearKey];
    
    //标签排序描述器
    NSSortDescriptor *labelDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"label" ascending:YES];
    
    //酒排序描述器
    NSSortDescriptor *wineDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"wine" ascending:YES];
    
    //排序
    [theLattice sortUsingDescriptors:@[labelDescriptor, wineDescriptor] ];
}


#pragma mark - 析构
- (void)dealloc
{
    [_lattices release];
    
    [super dealloc];
}


@end








