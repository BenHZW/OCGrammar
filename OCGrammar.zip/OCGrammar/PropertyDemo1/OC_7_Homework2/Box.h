//
//  Box.h
//  OC_7_Homework2
//
//  Created by Ibokan_Teacher on 15/8/28.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>

@class Wine;

@interface Box : NSObject

//Box拥有Wine
@property(nonatomic, retain)Wine *wine;

//标签只能根据酒来获得，不能随便设置，因此只读
@property(nonatomic, readonly, copy)NSString *label;

@end






