//
//  Wine.h
//  OC_7_Homework2
//
//  Created by Ibokan_Teacher on 15/8/28.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Wine : NSObject

//两个只读属性
@property(nonatomic, readonly)NSInteger year;
@property(nonatomic, readonly, copy)NSString *name;

//分析得出还必须有一个便利初始化方法
- (id)initWithName:(NSString*)name
              year:(NSInteger)year;

//标准的compare方法
- (NSComparisonResult)compare:(Wine*)anotherWine;

@end






