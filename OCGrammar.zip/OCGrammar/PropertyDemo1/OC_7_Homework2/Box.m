//
//  Box.m
//  OC_7_Homework2
//
//  Created by Ibokan_Teacher on 15/8/28.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import "Box.h"
#import "Wine.h"

@implementation Box

#pragma mark - 重写默认初始化方法
- (id)init
{
    if (self = [super init])
    {
        //一开始盒子里没有酒，标签设为None
        _label = [@"None" copy];
    }
    return self;
}


#pragma mark - 重写酒的setter
- (void)setWine:(Wine *)wine
{
    //1.将_wine设置好
    [wine retain];
    
    [_wine release];
    
    _wine = wine;
    
    
    //2.联动设置标签
    NSString *newLabel;
    if (_wine)//有酒
    {
        newLabel = [_wine.name copy];
    }
    else //没有酒
    {
        newLabel = [@"None" copy];
    }
    
    [_label release];
    
    _label = newLabel;
    
    
}


#pragma mark - 重写description
- (NSString *)description
{
    return [NSString stringWithFormat:@"Box %@: %@", self.label, self.wine];
}

#pragma mark - 析构方法
- (void)dealloc
{
    [_wine release];
    
    [_label release];
    
    [super dealloc];
}


@end






