//
//  main.m
//  OC_7_Homework2
//
//  Created by Ibokan_Teacher on 15/8/28.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        //自行调用做测试
        
        
    }
    return 0;
}





