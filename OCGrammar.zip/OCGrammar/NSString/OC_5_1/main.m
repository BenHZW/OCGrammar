//
//  main.m
//  OC_5_1
//
//  Created by Ibokan_Teacher on 15/8/20.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        //1.创建NSString（不可变字符串）对象
        
        unichar abc[4] = { 'a', 'b', 'c', '\0' };
        
        NSString *str1 = [[NSString alloc] initWithCharacters:abc length:3];
        
        NSString *str2 = [NSString stringWithString:str1];
        
        //@"string"语法只能表示不可变字符串对象
        NSString *str3 = @"123erfdsgfg";
      
        str3 = @"123";
        //通过C语言字符串构建NSString对象
        char cChar[] = "c char";
        NSString *str4 = @(cChar);
     
        
        NSLog(@"str1: %@", str1);
        NSLog(@"str2: %@", str2);
        NSLog(@"str3: %@", str3);
        NSLog(@"str4: %@", str4);
        
        
        //2.字符串长度
        NSUInteger str1l = [str1 length];
        NSUInteger str2l = str2.length;
        
        NSLog(@"str1l: %lu", str1l);
        NSLog(@"str2l: %lu", str2l);
        
        
        //3.字符串拼接
        
        //这个方法会返回一个新的拼接好的字符串
        NSString *str5 = [str3 stringByAppendingString:@" pinjie"];
        NSLog(@"str5: %@", str5);
        
        //原有的字符串不会变化
        NSLog(@"str3: %@", str3);
        
        
        
        //4.格式化字符串
        NSInteger i1 = 9;
        CGFloat f1 = 6.28;
        
        NSString *str6 = [[NSString alloc] initWithFormat:@"str4:%@,%%@ i1:%ld, f1:%f", str4, i1, f1];
        NSLog(@"str6: %@", str6);
        
        //还有stringWithFormat
        
        
        //5.字符串比较
        
        //5.1.指针比较
        NSString *str7 = @"iOS25";
        NSString *str8 = @"iOS25";
        
        NSLog(@"str7 == str8 ? %d", str7 == str8);
        
        
        //5.2.比较字符串内容是否相等
        BOOL str7EqualToStr8 = [str7 isEqualToString:str8];
        NSLog(@"str7EqualToStr8: %d", str7EqualToStr8);
        
        NSLog(@"str8 Equal to \"123\" ? %d", [str8 isEqualToString:@"123"]);
        
        
        //5.3.比较字符串大小
        NSString *str9 = @"ios25";
        NSComparisonResult str9CmpStr8 = [str9 compare:str8];
        NSLog(@"str9CmpStr8: %ld", str9CmpStr8);
        
        
        //条件比较
        NSString *str10 = @"Foo7.txt";
        NSString *str11 = @"fOO25.txt";
        
        //用位或运算连接多个枚举选项
        NSComparisonResult str10CmpStr11 = [str10 compare:str11 options:NSCaseInsensitiveSearch | NSNumericSearch];
        NSLog(@"str10CmpStr11: %ld", str10CmpStr11);
        
        
        //6.NSRange结构体
        NSRange range1 = NSMakeRange(1, 3);
        //location表示范围的起始位置
        //length表示范围长度
        
        
        //7.截取字符串
        
        //7.1.根据范围截取字符串
        NSString *str12 = [@"abcdefg" substringWithRange:range1];
        NSLog(@"str12: %@", str12);
        
        
        //7.2.根据头尾下标截取
        
        //截取指定下标之后的字符串
        NSString *str13 = [@"ZXGDDEEG" substringFromIndex:4];
        NSLog(@"str13: %@", str13);
        
        //截取指定下标之前的字符串
        NSString *str14 = [@"9876543" substringToIndex:3];
        NSLog(@"str14: %@", str14);
        
        
        //7.3.截取出一个字符
        NSString *str15 = @"今天学习字符串";
        unichar xue = [str15 characterAtIndex:2];
        NSLog(@"xue: %C", xue);
        
        
        //8.字符串搜索
        NSString *str16 = @"小明今天很帅！";
        
        NSRange range2 = [str16 rangeOfString:@"很帅"];
        
        NSLog(@"range2: %@", NSStringFromRange(range2) );
        
        
        //搜索不到的情况
        NSRange range3 = [str16 rangeOfString:@"丑"];
        
        NSLog(@"range3: %@", NSStringFromRange(range3) );
        
        //当结果为“找不到”时，location的值为：
        if (range3.location == NSNotFound)
        {
            NSLog(@"找不到“丑”");
        }
        
        
        //判定字符串的开头和结尾
        NSString *str17 = @"xyz123";
        
        //判断开头
        BOOL str17Xyhead = [str17 hasPrefix:@"xy"];
        
        NSLog(@"str17Xyhead: %d", str17Xyhead);
        
        //判断结尾
        NSLog(@"str17 end with 123 ? %d", [str17 hasSuffix:@"321"]);
        
        
        //9.字符串替换
        NSString *str18 = @"iOS22";
        
        NSString *str19 = [str18 stringByReplacingCharactersInRange:NSMakeRange(3, 2) withString:@"-25"];
        NSLog(@"str19: %@", str19);
        
        
        
        NSString *str20 = @"xxxxyyxxyyxxxyyxxxyyxxx";
        
        NSString *str21 = [str20 stringByReplacingOccurrencesOfString:@"yy" withString:@"aa"];
        NSLog(@"str21: %@", str21);
    }
    return 0;
}






