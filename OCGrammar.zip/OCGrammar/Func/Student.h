//
//  Student.h
//  OC_2_1
//
//  Created by Ibokan_Teacher on 15/8/17.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Student : NSObject

//类的实例变量
{
    @public//表示在类的外部能访问这些实例变量
    
    NSInteger age;
    
    //NSString是OC里面的字符串类
    NSString *name;
    
    CGFloat height;
}


//实例方法：只有对象（实例）才能执行的方法
//又叫做“减号方法”
- (void)run:(NSUInteger)km;


//类方法：只能通过类名才能调用的方法
//又叫做“加号方法”
+ (void)showInstanceVariables;



@end












