//
//  main.m
//  OC_2_1
//
//  Created by Ibokan_Teacher on 15/8/17.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Student.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        //1.创建一个类的对象（实例化一个类）
        Student *stu1 = [[Student alloc] init];
        
        Student *stu2 = [Student new];
        
        
        //2.访问对象的公开实例变量
        stu1->age = 18;
        
        stu1->name = @"YSG";
        
        stu1->height = 1.80;
        
        
        //3.打印对象信息
        NSLog(@"stu1->age: %ld", stu1->age);
        
        
        //NSLog可以直接打印一个对象，用%@表示
        NSLog(@"stu1: %@", stu1);
        
        
        //4.调用实例方法
        //通过一个对象去调用
        [stu1 run:50];
        
        
        //5.调用类方法
        //需要通过类名来调用
        [Student showInstanceVariables];
        
        
    }
    return 0;
}








