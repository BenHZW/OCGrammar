//
//  Student.m
//  OC_2_1
//
//  Created by Ibokan_Teacher on 15/8/17.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import "Student.h"

@implementation Student

- (void)run:(NSUInteger)km
{
    //在实例方法中，self就是指向调用这个方法的对象的一个指针
    NSLog(@"%@ ran %lu km", self->name, km);
//    NSLog(@"%@ ran %lu km", name, km);
}


+ (void)showInstanceVariables
{
    //在类方法里面，self表示这个类的名字
    NSLog(@"class name: %@", [self class] );
    NSLog(@"age, name, height");
    
    //在类方法里面，能使用self调用实例变量和实例方法吗？
}


@end








