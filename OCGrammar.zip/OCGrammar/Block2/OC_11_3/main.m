//
//  main.m
//  OC_11_3
//
//  Created by Ibokan_Teacher on 15/9/6.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Student.h"
#import "Teacher.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        Student *stu1 = [Student new];
        stu1.name = @"first";
        
        Student *stu2 = [Student new];
        stu2.name = @"second";
        
        NSArray *studentList = @[stu1, stu2];
        
        
        //在这里可定义Teacher点名（代码块）的行为
        Teacher *teacher1 = [Teacher new];
        teacher1.callTheRoll = ^()
        {
            for (Student *stu in studentList)
            {
                NSLog(@"%@", stu);
            }
            
            NSLog(@"student count: %ld", studentList.count);
        };
        
        teacher1.callTheRoll();
        
    }
    return 0;
}




