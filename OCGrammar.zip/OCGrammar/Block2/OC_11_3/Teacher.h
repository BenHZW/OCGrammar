//
//  Teacher.h
//  OC_11_3
//
//  Created by Ibokan_Teacher on 15/9/6.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>

//代码块取“别名”
typedef void(^CallTheRoll)();

@interface Teacher : NSObject

//用一个代码块对象作为属性
//@property(nonatomic, copy)void (^callTheRoll)();
@property(nonatomic, copy)CallTheRoll callTheRoll;

@end












