//
//  Monitor.h
//  OC-10-Homework2
//
//  Created by Ibokan on 14-12-1.
//  Copyright (c) 2014年 fghf. All rights reserved.
//

#import "Student.h"
#import "CallTheRoll.h"

//班长继承于学生，实现点名协议
@interface Monitor : Student<CallTheRoll>


@end






