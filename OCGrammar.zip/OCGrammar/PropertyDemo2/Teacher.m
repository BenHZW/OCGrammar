//
//  Teacher.m
//  OC-10-Homework2
//
//  Created by Ibokan on 14-12-1.
//  Copyright (c) 2014年 fghf. All rights reserved.
//

#import "Teacher.h"
#import "Student.h"

//唯一对象
static Teacher *teacher;


@implementation Teacher


- (void)callTheRoll
{
    //这里调用代理人的点名方法
    
    
    //最后把名单给代理人，让代理人点名
    NSInteger studentCount = [self.delegate callTheRoll:self.studentList];
    
    NSLog(@"老师知道人数为%ld", studentCount);
    
}

- (void)dealloc
{
    [_studentList release];
    
    [super dealloc];
}


#pragma mark - 单例模式相关方法

+ (void)initialize
{
    @synchronized(self)
    {
        if(teacher == nil)
            teacher = [[self alloc] init];
    }
}

+ (id)defaultTeacher
{
    return teacher;
}

+ (id)allocWithZone:(struct _NSZone *)zone
{
    @synchronized(teacher)
    {
        if (teacher == nil)
            teacher = [super allocWithZone:zone];
    }
    return teacher;
}

- (id)retain
{
    return self;
}

- (NSUInteger)retainCount
{
    return NSUIntegerMax;
}

- (oneway void)release
{}

- (id)autorelease
{
    return self;
}

@end





