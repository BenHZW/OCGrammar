//
//  Teacher.h
//  OC-10-Homework2
//
//  Created by Ibokan on 14-12-1.
//  Copyright (c) 2014年 fghf. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CallTheRoll.h"
@class Student;
@interface Teacher : NSObject

//教师的代理人，要能点名
@property(nonatomic, assign)id<CallTheRoll> delegate;

//学生名单
@property(nonatomic, copy)NSArray *studentList;


//老师自己也要有点名方法，实质是在里面让代理人点名
- (void)callTheRoll;


//单例工厂方法
+ (id)defaultTeacher;



@end






