//
//  Student.h
//  OC-10-Homework2
//
//  Created by Ibokan on 14-12-1.
//  Copyright (c) 2014年 fghf. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Student : NSObject

//关于学生的一些属性和方法
@property(nonatomic, copy)NSString *name;

@property(nonatomic)NSInteger age;

- (id)initWithName:(NSString*)name;


@end




