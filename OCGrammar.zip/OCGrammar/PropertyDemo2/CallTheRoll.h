//
//  CallTheRoll.h
//  OC-10-Homework2
//
//  Created by Ibokan on 14-12-1.
//  Copyright (c) 2014年 fghf. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol CallTheRoll <NSObject>

//点名的协议方法，需要通过参数传入一份名单，返回名单人数
- (NSInteger)callTheRoll:(NSArray*)objs;

@end





