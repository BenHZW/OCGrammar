//
//  main.m
//  OC-10-Homework2
//
//  Created by Ibokan on 14-12-1.
//  Copyright (c) 2014年 fghf. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "Student.h"
#import "Monitor.h"
#import "Teacher.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        Student *stu1 = [[Student alloc] initWithName:@"张三"];
        //自行设置年龄、地址
        
        //弄一个学生名单
        Student *stu2 = [[Student alloc] initWithName:@"老王"];
        
        Monitor *stu3 = [[Monitor alloc] initWithName:@"班长"];
        
        
        //一个老师
        Teacher *teacher = [Teacher new];
        
        //老师获得学生名单
        teacher.studentList = @[stu1, stu2, stu3];
        
        //老师的代理人是班长
        teacher.delegate = stu3;
        
        //点名
        [teacher callTheRoll];
        
        
        
        //释放内存
        [stu1 release];
        [stu2 release];
        [stu3 release];
        [teacher release];
        
    }
    return 0;
}




