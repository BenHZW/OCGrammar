//
//  Student.m
//  OC-10-Homework2
//
//  Created by Ibokan on 14-12-1.
//  Copyright (c) 2014年 fghf. All rights reserved.
//

#import "Student.h"

@implementation Student

- (id)initWithName:(NSString *)name
{
    self = [super init];
    if (self)
    {
        _name = [name copy];
    }
    return self;
}

- (void)dealloc
{
    [_name release];
    
    [super dealloc];
}

@end





