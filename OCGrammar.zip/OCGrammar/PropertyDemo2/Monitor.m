//
//  Monitor.m
//  OC-10-Homework2
//
//  Created by Ibokan on 14-12-1.
//  Copyright (c) 2014年 fghf. All rights reserved.
//

#import "Monitor.h"

@implementation Monitor

- (NSInteger)callTheRoll:(NSArray *)objs
{
    for (Student *stu in objs)
    {
        NSLog(@"%@", stu.name);
    }
    
    return objs.count;
}

@end




