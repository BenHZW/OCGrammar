//
//  NSString+StringCharacter.m
//  OC_9_1
//
//  Created by Ibokan_Teacher on 15/8/31.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import "NSString+StringCharacter.h"

@implementation NSString (StringCharacter)

- (NSString *)characterStringAtIndex:(NSUInteger)index
{
    //1.获取本字符串对应下标的字符
    unichar uc = [self characterAtIndex:index];
    
    //2.转成字符串并返回
    return [NSString stringWithFormat:@"%C", uc];
}

@end







