//
//  EBook.h
//  OC_9_1
//
//  Created by Ibokan_Teacher on 15/8/31.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>

//遵守了NSCopying协议才能调用copy方法
//遵守了NSMutableCopying协议才能调用mutableCopy方法
@interface EBook : NSObject<NSCopying, NSMutableCopying>

//电子书的文本
@property(nonatomic, copy)NSString *text;

@end


//把初始化有关的一些方法分类写在一个类目里
@interface EBook (Initialization)

//instancetype：指代这个方法所在的当前类型

- (instancetype)initWithText:(NSString*)text;

+ (instancetype)eBookWithText:(NSString*)text;

@end






