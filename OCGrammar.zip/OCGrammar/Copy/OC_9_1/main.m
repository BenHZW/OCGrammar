//
//  main.m
//  OC_9_1
//
//  Created by Ibokan_Teacher on 15/8/31.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NSString+StringCharacter.h"

#import "EBook.h"
#import "EBookPrinter.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        //1.使用类目方法
        NSString *str1 = [@"ASDFGHJKL:" characterStringAtIndex:4];
        NSLog(@"str1: %@", str1);
        
        
        
        //2.协议的用途
        EBook *eBook1 = [EBook eBookWithText:@"REWQ"];
        
        EBookPrinter *ep1 = [EBookPrinter new];
        
        
        //用这种形式表示遵守了某个协议的任意对象
        id<EBookProcess> processor = ep1;
        
        
        //检测一个对象是否遵守某个协议
        if( [processor conformsToProtocol:@protocol(EBookProcess)] )
        {
            [processor printEBook:eBook1];
        }
        
        
        //EBook浅拷贝
        EBook *eBook2 = [eBook1 copy];
        NSLog(@"eBook1 == eBook2 ? %d", eBook1 == eBook2);
        
        //EBook深拷贝
        EBook *eBook3 = [eBook1 mutableCopy];
        NSLog(@"eBook1 == eBook3 ? %d", eBook1 == eBook3);
        
        
        //检测一个对象是否实现了某个方法
        if( [processor respondsToSelector:@selector(copyEBook:)] )
        {
            EBook *eBook4 = [processor copyEBook:eBook1];
            NSLog(@"eBook4 == eBook1 ? %d", eBook4 == eBook1);
        }
        
        
        
    }
    return 0;
}





