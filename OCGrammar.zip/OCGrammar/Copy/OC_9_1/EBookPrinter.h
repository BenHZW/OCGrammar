//
//  EBookPrinter.h
//  OC_9_1
//
//  Created by Ibokan_Teacher on 15/8/31.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "EBookProcess.h"

//<协议名>表示这个类遵守了这个协议
@interface EBookPrinter : NSObject<EBookProcess>

//遵守协议后就相当于已经声明了这个协议里面的方法，不必重复声明


@end










