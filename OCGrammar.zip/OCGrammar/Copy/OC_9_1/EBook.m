//
//  EBook.m
//  OC_9_1
//
//  Created by Ibokan_Teacher on 15/8/31.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import "EBook.h"

@implementation EBook

#pragma mark - NSCopying协议方法
- (id)copyWithZone:(NSZone *)zone
{
    //比如我们定义这个是浅拷贝
    return self;
    
    //如果是MRC环境，要：
    //return [self retain];
}

#pragma mark - NSMutableCopying协议方法
- (id)mutableCopyWithZone:(NSZone *)zone
{
    //比如我们定义这个方法是深拷贝
    
    //创建新对象
    EBook *newEBook = [[[self class] alloc] initWithText:self.text];
    
    //注意：即使在MRC下也不要autorelease
    return newEBook;
}

@end


//类目方法要在类目的implementation里面实现
@implementation EBook (Initialization)

- (instancetype)initWithText:(NSString *)text
{
    if (self = [super init])
    {
        _text = [text copy];
    }
    return self;
}

+ (instancetype)eBookWithText:(NSString *)text
{
    EBook *ebook = [[self alloc] initWithText:text];
    
    return ebook;
}


@end












