//
//  EBookPrinter.m
//  OC_9_1
//
//  Created by Ibokan_Teacher on 15/8/31.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import "EBookPrinter.h"
#import "EBook.h"

@implementation EBookPrinter

//协议中required的方法必须实现
- (void)printEBook:(EBook *)eBook
{
    NSLog(@"eBook.text: %@", eBook.text);
}

//可选的协议方法可以不实现，也可以实现
- (EBook *)copyEBook:(EBook *)eBook
{
    //比如此方法要深拷贝一本书
    
    //如果是MRC环境，此处要加上autorelease
    return [eBook mutableCopy];
}



@end




