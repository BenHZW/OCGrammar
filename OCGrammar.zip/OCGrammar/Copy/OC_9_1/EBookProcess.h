//
//  EBookProcess.h
//  OC_9_1
//
//  Created by Ibokan_Teacher on 15/8/31.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>

@class EBook;

//后面的尖括号里可理解为<父协议>
//或者统一理解为遵守某个协议

@protocol EBookProcess <NSObject>

//协议规定了一些方法，只有声明，没有实现
//交给遵守这个协议的类去实现

@required //此标记表示这个方法必须实现
//如果不写任何标记，默认就是@required
- (void)printEBook:(EBook*)eBook;


@optional //此标记表示可选方法，即使遵守了协议也不一定要实现
- (EBook*)copyEBook:(EBook*)eBook;

@end







