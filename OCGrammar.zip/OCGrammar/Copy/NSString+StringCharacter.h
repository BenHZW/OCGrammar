//
//  NSString+StringCharacter.h
//  OC_9_1
//
//  Created by Ibokan_Teacher on 15/8/31.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>

//类目的作用：为已经存在的类增加新的方法

@interface NSString (StringCharacter)

//根据下标获得对应的字符，并以字符串的形式返回

- (NSString*)characterStringAtIndex:(NSUInteger)index;


//允许在类目里面重写一个类原有的方法，但是不建议

@end








