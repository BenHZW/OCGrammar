//
//  main.m
//  OC_3_3
//
//  Created by Ibokan_Teacher on 15/8/19.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Student.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool
    {
        NSLog(@"1.create a Student object");
        Student *stu1 = [Student new];
        
        NSLog(@"2.set stu1 name and age");
        stu1.name = @"Jcak";
        stu1.age = 15;
        
        NSLog(@"%@", stu1);
        
        
    }
    return 0;
}

