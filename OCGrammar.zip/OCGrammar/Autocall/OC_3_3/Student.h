//
//  Student.h
//  OC_3_3
//
//  Created by Ibokan_Teacher on 15/8/19.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Student : NSObject

@property(nonatomic, copy)NSString *name;
@property(nonatomic)NSInteger age;

@end






