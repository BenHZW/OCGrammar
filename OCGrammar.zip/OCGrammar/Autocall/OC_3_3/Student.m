//
//  Student.m
//  OC_3_3
//
//  Created by Ibokan_Teacher on 15/8/19.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import "Student.h"

@implementation Student

//认识一些继承于NSObject的方法

#pragma mark - 类的初始化方法
//这个方法，当这个类首次被提及的时候会自动调用
//一般不手动调用
+ (void)initialize
{
    [super initialize];
    NSLog(@"Student class initialized");
}


#pragma mark - 对象转换输出字符处的方法
//当类的对象被代入到字符处中时，会自动调用此方法，得出字符串（返回值）后代入
- (NSString *)description
{
    return [NSString stringWithFormat:@"Student %@, %ld years old.", self.name, self.age];
}



@end









