//
//  Agent.m
//  OC_10_1
//
//  Created by Ibokan_Teacher on 15/9/1.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import "Agent.h"

#import "AppleCompany.h"

@implementation Agent

#pragma mark - 实现协议方法
- (void)sellIphone:(NSString *)iPhone
{
    NSLog(@"%@代理卖%@", self.name, iPhone);
    
    //从付款人出获取钱
    NSLog(@"%@获得%lu", self.name, [self.payer payMoney]);
}


@end




