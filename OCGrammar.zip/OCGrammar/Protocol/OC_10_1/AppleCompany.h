//
//  AppleCompany.h
//  OC_10_1
//
//  Created by Ibokan_Teacher on 15/9/1.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>

#pragma mark - 苹果公司类

//这样写表示知道有这个协议，可以用
@protocol SellIphone;
  
//苹果公司要遵守付款协议
@protocol PayMoney;

@interface AppleCompany : NSObject<PayMoney>

//代理人属性
//一般使用弱引用（weak或assign）
//不管谁做代理，只要遵守协议即可
@property(nonatomic, weak)id<SellIphone> delegate;


//委托代理人去卖iPhone的方法
//用一个字符串描述iPhone
- (void)sellIPhoneViaDelegate:(NSString*)iPhone;


@end




#pragma mark - 让代理商去遵守的协议


@protocol SellIphone <NSObject>

//暂时用字符串描述一台iPhone
- (void)sellIphone:(NSString*)iPhone;

@end









