//
//  AppleCompany.m
//  OC_10_1
//
//  Created by Ibokan_Teacher on 15/9/1.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import "AppleCompany.h"
#import "Agent.h"

@implementation AppleCompany

#pragma mark - 委托代理人卖iPhone

- (void)sellIPhoneViaDelegate:(NSString *)iPhone
{
    NSLog(@"苹果公司要卖%@", iPhone);
    
    //让代理人帮忙卖手机（调用代理人遵守的协议方法）
    [self.delegate sellIphone:iPhone];
    
}

#pragma mark - 实现付钱协议方法
- (NSUInteger)payMoney
{
    NSLog(@"苹果公司付钱");
    return 3000;
}

@end







