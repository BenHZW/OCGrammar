//
//  main.m
//  OC_10_1
//
//  Created by Ibokan_Teacher on 15/9/1.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AppleCompany.h"
#import "Agent.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        AppleCompany *apple = [AppleCompany new];
        
        Agent *agent1 = [Agent new];
        agent1.name = @"广州代理商";
        
        
        //给苹果公司设置代理人
        apple.delegate = agent1;
        
        
        //给代理商设置付款人
        agent1.payer = apple;
        
        
        //苹果公司卖手机
        [apple sellIPhoneViaDelegate:@"iPhone6"];
        
        
    }
    return 0;
}





