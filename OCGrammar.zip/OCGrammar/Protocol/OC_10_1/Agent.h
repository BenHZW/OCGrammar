//
//  Agent.h
//  OC_10_1
//
//  Created by Ibokan_Teacher on 15/9/1.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>


//作为代理商，要遵守苹果公司定下的卖手机协议

@protocol SellIphone;
@protocol PayMoney;

#pragma mark - 代理商类

//代理商要遵守卖手机的协议
@interface Agent : NSObject<SellIphone>

@property(nonatomic, copy)NSString *name;

//付款人的属性
//不必知道付款人是谁，只要他会付钱（遵守付钱协议）即可
@property(nonatomic, weak)id<PayMoney> payer;

@end


#pragma mark - 委托方要遵守的付钱协议

@protocol PayMoney <NSObject>

- (NSUInteger)payMoney;

@end












