//
//  Person.h
//  OC_12_3
//
//  Created by Ibokan_Teacher on 15/9/6.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Person : NSObject



//下面两个将定义为通知回调方法
//当Person接收到通知后，要自动调用对应的方法，而该通知将以参数的形式传入方法内
//根据实际需要决定是否保留这个参数

//逃跑方法
- (void)escape:(NSNotification*)notification;

//停止逃跑的方法
- (void)stop:(NSNotification*)notification;


@end







