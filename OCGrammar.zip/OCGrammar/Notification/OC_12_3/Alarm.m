//
//  Alarm.m
//  OC_12_3
//
//  Created by Ibokan_Teacher on 15/9/6.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import "Alarm.h"

@implementation Alarm

- (void)startAlarming
{
    NSLog(@"警报响起，发出通知");
    
    //1.创建通知对象
    //参数①通知名称，通知的唯一识别符
    //参数②通知的发送人，可以填nil相当于匿名
    //参数③用字典表示通知的“正文”
    NSNotification *startAlarmNotification = [NSNotification notificationWithName:@"startAlarming" object:self userInfo:@{@"date":[NSDate date]}];
    
    //2.获取通知中心
    NSNotificationCenter *notificationCenter = [NSNotificationCenter defaultCenter];
    
    //3.使用通知中心发送通知
    [notificationCenter postNotification:startAlarmNotification];
    
}


- (void)stopAlarming
{
    NSLog(@"警报解除");
    
    //1.获取通知中心
    NSNotificationCenter *notificationCenter = [NSNotificationCenter defaultCenter];
    
    //2.直接定义通知内容并发送
    [notificationCenter postNotificationName:@"stopAlarming" object:self userInfo:@{@"date":[NSDate date]}];
    
}


@end







