//
//  Person.m
//  OC_12_3
//
//  Created by Ibokan_Teacher on 15/9/6.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import "Person.h"

@implementation Person

- (instancetype)init
{
    self = [super init];
    if (self)
    {
        //添加自身作为观察者
        
        //1.获取通知中心
        NSNotificationCenter *notificationCenter = [NSNotificationCenter defaultCenter];
        
        //2.通知中心添加观察者
        //参数②观察者接收到通知后回调的方法，用selector表示
        //参数④指定观察者专门观察由谁发送的通知（指定发送人），填nil表示不指定发送人（任意发送人）
        [notificationCenter addObserver:self selector:@selector(escape:) name:@"startAlarming" object:nil];
        
        [notificationCenter addObserver:self selector:@selector(stop:) name:@"stopAlarming" object:nil];
    }
    return self;
}


- (void)dealloc
{
    //移除观察者
    NSNotificationCenter *notificationCenter = [NSNotificationCenter defaultCenter];
    
    //一次过移除观察者对所有通知的观察
    [notificationCenter removeObserver:self];
}

#pragma mark - 接收到通知后回调的方法
- (void)escape:(NSNotification *)notification
{
    //从通知对象中获取需要的数据
    NSDictionary *userInfo = notification.userInfo;
    
    NSDate *date = userInfo[@"date"];
    
    NSLog(@"%@听到警报，快跑！", date);
}

- (void)stop:(NSNotification *)notification
{
    //步骤跟escape类似
    
    NSDictionary *userInfo = notification.userInfo;
    
    NSDate *date = userInfo[@"date"];
    
    NSLog(@"%@警报解除。不用跑了。", date);
    
}

@end







