//
//  main.m
//  OC_12_3
//
//  Created by Ibokan_Teacher on 15/9/6.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Person.h"
#import "Alarm.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        Alarm *alarm1 = [Alarm new];
        
        Person *person1 = [Person new];
        
        [alarm1 startAlarming];
        
        [alarm1 stopAlarming];
        
    }
    return 0;
}

