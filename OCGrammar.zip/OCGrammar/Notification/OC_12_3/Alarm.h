//
//  Alarm.h
//  OC_12_3
//
//  Created by Ibokan_Teacher on 15/9/6.
//  Copyright (c) 2015年 ios22. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Alarm : NSObject

//报警
- (void)startAlarming;

//停止报警
- (void)stopAlarming;

@end






