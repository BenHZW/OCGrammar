//
//  Teacher.m
//  OC-12-HomeWork2
//
//  Created by Ibokan_Teacher on 15-4-29.
//  Copyright (c) 2015年 fghf. All rights reserved.
//

#import "Teacher.h"

@implementation Teacher


- (void)postANotificationWithContent:(NSString *)text
{
    //把文本封装在字典里面
    NSDictionary *userInfo = @{@"text":text};
    
    //创建通知对象
    NSNotification *nf = [NSNotification notificationWithName:@"nfFromTeacher" object:self userInfo:userInfo];
    
    
    //通过通知中心发通知
    [[NSNotificationCenter defaultCenter] postNotification:nf];
    
    
}


@end




