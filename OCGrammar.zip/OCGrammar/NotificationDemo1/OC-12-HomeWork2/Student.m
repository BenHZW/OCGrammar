//
//  Student.m
//  OC-12-HomeWork2
//
//  Created by Ibokan_Teacher on 15-4-29.
//  Copyright (c) 2015年 fghf. All rights reserved.
//

#import "Student.h"

@implementation Student

//直接在初始化的时候添加通知观察者
- (id)init
{
    if (self = [super init])
    {
        //添加观察通知中心
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(receiveNotification:) name:@"nfFromTeacher" object:nil];
    }
    return self;
}

- (void)receiveNotification:(NSNotification*)nf
{
    NSDictionary *userInfo = nf.userInfo;
    ;
    NSLog(@"通知内容：");
    //提取字典内容
    for (NSString *key in userInfo)
    {
        NSLog(@"%@", userInfo[key]);
    }
    
}

- (void)dealloc
{
    //移除观察者
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

@end






