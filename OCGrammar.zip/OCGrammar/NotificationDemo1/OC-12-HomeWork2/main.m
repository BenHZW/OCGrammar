//
//  main.m
//  OC-12-HomeWork2
//
//  Created by Ibokan_Teacher on 15-4-29.
//  Copyright (c) 2015年 fghf. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Teacher.h"
#import "Student.h"
int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        Teacher *teacher = [Teacher new];
        
        Student *stu1 = [Student new];
        
        Student *stu2 = [Student new];
        
        
        [teacher postANotificationWithContent:@"五一放假"];
        
    }
    return 0;
}

