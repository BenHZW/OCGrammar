//
//  Student.h
//  OC-12-HomeWork2
//
//  Created by Ibokan_Teacher on 15-4-29.
//  Copyright (c) 2015年 fghf. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Student : NSObject

@end
