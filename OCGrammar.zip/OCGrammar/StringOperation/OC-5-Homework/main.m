//
//  main.m
//  OC-5-Homework
//
//  Created by CJJMac on 15-4-15.
//  Copyright (c) 2015年 CJJMac. All rights reserved.
//

#import <Foundation/Foundation.h>


int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
#pragma mark - 1
        NSMutableString *text = [[NSMutableString alloc] initWithString:@"　　根据美国一家市场调研公司Slice Intelligence的最新报告，4月10日Apple Watch（苹果手表）在美国开放预售的当天，已经接收到了100万个订单，“销售一空”的结果是，如果顾客想现在订货，恐怕要等到6月份才能交付产品。\n　　中国市场上同样如此。开放销售6小时内，所有的Apple Watch被“销售一空”。再预定的话，也必须等上1-2个月。\n　　一面是经过媒体放大宣传之后的“销售一空”和苹果CEO库克亲临零售店时的“龙颜大悦”，另一面是苹果公司刻意对外不宣布Apple Watch的销售数据（包括在其下一季度财报中，苹果公司表示，也不会单独公布Apple Watch的销量，只会和其他产品合并计算）。"];
        
        //确定第1个回车的位置
        NSRange range = [text rangeOfString:@"\n"];
        
        
        //在剩下的范围内，替换Apple Watch
        //剩余部分的字符串长度
        NSUInteger remainLength = text.length - range.location - 1;
        
        //剩余的范围
        NSRange remainRange = NSMakeRange(range.location + 1, remainLength);
        
        [text replaceOccurrencesOfString:@"Apple Watch" withString:@"苹果手表" options:0 range:remainRange];
        NSLog(@"%@", text);

        
#pragma mark - 2
        NSMutableString * mstr= [NSMutableString stringWithString: @"iphoneAndroid"];
        [mstr deleteCharactersInRange:NSMakeRange(6, 7)];
        NSLog(@"mstr: %@", mstr);
        
#pragma mark - 3
        //字符串转数字
        NSInteger i1 = [@"158" integerValue];
        NSInteger i2 = [@"39" integerValue];
        
        //数字转字符串
        NSString *difference = [NSString stringWithFormat:@"%ld", i1 - i2];
        NSLog(@"difference: %@", difference);
        
        
#pragma mark - 4
        NSString *str2 = @"这句话共有二十七个字，而我想告诉你的是第十二、十三、十六个字。";
        //注意数下标
        unichar c1 = [str2 characterAtIndex:12];
        unichar c2 = [str2 characterAtIndex:13];
        unichar c3 = [str2 characterAtIndex:16];
        
        NSString *str3 = [NSString stringWithFormat:@"%C%C%C", c1, c2, c3];
        NSLog(@"str3: %@", str3);
        
    }
    return 0;
}

